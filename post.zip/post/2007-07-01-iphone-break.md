---
title: iPhone 拆解！
author: elion
date: 2007-07-01T14:44:18+00:00
url: /2007/07/01/iphone-break/
views:
  - 125
categories:
  - 分享好玩
tags:
  - 杂文分享
  - hosted-on-blogbus
draft: false

---
![][1]  
该来的，总是会来的 XD。像所有的重大数字产品一样，开箱之后，就是拆拆拆啦！这回的凶手是名为 ifixit 的网站，而在他们的发现中，最重要的大概有几个：

一、电池是焊在电路板上的，所以自已换电池要费的功夫恐怕是非常大的。  

二、iPhone 是有 SIM 卡插座的  

三、iPhone 的空间没有完全利用到 &#8212; 在天线下还有一点空间 &#8212; 或许未来可以塞个 GPS 什么的？


除了 ifixit 外，Think Secret 也有一整篇的开盒 + 拆解照，真的有兴趣的朋友不妨过去看看～

 [1]: http://www.engadget.com/media/2007/06/iphone-splayed.jpg