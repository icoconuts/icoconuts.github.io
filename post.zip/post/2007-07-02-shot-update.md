---
title: Shot update
author: elion
date: 2007-07-02T13:52:13+00:00
url: /2007/07/02/shot-update/
views:
  - 136
categories:
  - 分享好玩
tags:
  - 壁纸
  - 美化
  - hosted-on-blogbus
draft: false

---
  
[Shot update][1] by ~[Andycap][2]{.u} on [deviant][3][ART][3]

 [1]: http://www.deviantart.com/deviation/52556020/
 [2]: http://andycap.deviantart.com/
 [3]: http://www.deviantart.com