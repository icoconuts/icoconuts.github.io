---
title: -Tragic Endings-
author: elion
date: 2007-07-07T02:35:27+00:00
url: /2007/07/07/tragic-endings/
views:
  - 54
categories:
  - 分享好玩
tags:
  - 壁纸
  - 美化
  - hosted-on-blogbus
draft: false

---
  
[-Tragic Endings-][1] by =[BlackRibbonRose][2]{.u} on [deviant][3][ART][3]  
－－－－－－－－  
真想看看她的背景啊~~&#8217;  
~o~

 [1]: http://www.deviantart.com/deviation/59233838/
 [2]: http://blackribbonrose.deviantart.com/
 [3]: http://www.deviantart.com