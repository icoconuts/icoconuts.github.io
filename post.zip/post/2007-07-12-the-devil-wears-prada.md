---
title: The Devil Wears Prada
author: elion
date: 2007-07-12T07:56:49+00:00
url: /2007/07/12/the-devil-wears-prada/
views:
  - 97
categories:
  - 生活记事
tags:
  - 暂无分类
  - hosted-on-blogbus
draft: false

---

今天在市里逛，看到了这个影片，虽然不是什么新片，但想想喜剧应该不错。  

过会飞鸽上问问~~  

![][1]  
![][2]  
![][3]

 [1]: http://img2.poco.cn/movie/mov_photo/070220/596937_123046_400.jpg
 [2]: http://image2.sina.com.cn/ent/d/2007-01-30/U1825P28T3D1432462F326DT20070130165805.jpg
 [3]: http://image2.sina.com.cn/ent/d/2007-01-30/U1825P28T3D1432456F326DT20070130165737.jpg