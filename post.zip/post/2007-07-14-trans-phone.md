---
title: 手机变形金刚
author: elion
date: 2007-07-14T06:04:42+00:00
url: /2007/07/14/trans-phone/
views:
  - 109
categories:
  - 分享好玩
tags:
  - 杂文分享
  - hosted-on-blogbus
draft: false

---
手机变形金刚，酷得没话说！！  
三星JUNE：  
![][1]  
摘自engadget:http://cn.engadget.com/2007/07/13/transformers-phone-sports-lethal-theft-deterrent-system/

 [1]: http://www.blogsmithmedia.com/cn.engadget.com/media/2007/07/0602_000001_c3xqbk3t2z_1.jpg