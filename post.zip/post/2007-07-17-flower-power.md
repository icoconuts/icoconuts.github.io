---
title: Flower Power
author: elion
date: 2007-07-17T02:21:25+00:00
url: /2007/07/17/flower-power/
views:
  - 71
categories:
  - 分享好玩
tags:
  - 壁纸
  - 美化
  - hosted-on-blogbus
draft: false
---
  
[Flower Power][1] by *[iAmFreeman][2]{.u} on [deviant][3][ART][3]  
－－－－－－－－－－  
嗯，好酷~~  
可惜没有1024*768的，感觉有点落伍了。

 [1]: http://www.deviantart.com/deviation/59785900/
 [2]: http://iamfreeman.deviantart.com/
 [3]: http://www.deviantart.com