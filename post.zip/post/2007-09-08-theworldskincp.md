---
title: 世界之窗皮肤大赛获奖作品揭晓
author: elion
date: 2007-09-08T12:06:15+00:00
url: /2007/09/08/theworldskincp/
views:
  - 207
categories:
  - 分享好玩
tags:
  - 杂文分享
  - hosted-on-yo2
draft: false
---
![][1]  

为期二个月的皮肤大赛终于结束了。  

作为版主，我似乎没做什么。除了之前为“皮肤制作参考”做了点材料。 

之后，又是考试，又是心事，后来暑假回家。到最后入围投票都没看到。  

回来的时候入围结果都已经出来了。  

嗯，不去评价结果了，每个人都会有不同的看法的。我想。  

入围作品名单：  

http://www.ioage.com/huodong/skin_show.htm  

获奖名单：  

http://www.ioage.com/huodong/skin_Finally.htm  

祝贺以上几位。  

希望他们能继续为TW做出更多精美的皮肤，而不仅仅是为了得奖而付出。


 [1]: http://www.ioage.com/huodong/images/show2.jpg