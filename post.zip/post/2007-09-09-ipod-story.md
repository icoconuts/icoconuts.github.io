---
title: iPod之进化
author: elion
date: 2007-09-09T04:26:32+00:00
url: /2007/09/09/ipod-story/
views:
  - 155
categories:
  - 分享好玩
tags:
  - 杂文分享  
  - hosted-on-yo2
draft: false
---

CB上看到这么一张图片，使像我们这种不了解iPod的人来说真是一个全面直观的了解。  
![ipod][1]  
有兴趣的，可以看看CB上的具体介绍。  
http://www.cnbeta.com/articles/38489.htm

 [1]: http://www.cnbeta.com/upimg/070909/ugmbbc_120102.jpg