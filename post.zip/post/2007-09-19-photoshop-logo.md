---
title: Photoshop更新Logo
author: elion
date: 2007-09-19T12:19:51+00:00
url: /2007/09/19/photoshop-logo/
views:
  - 85
categories:
  - 分享好玩
tags:
  - 杂文分享
  - hosted-on-yo2
draft: false

---
![logo][1]  
<!--more-->
  
Photoshop即将更新Logo，与前一款Logo相比，出色不少。  

标语也改成了“See What&#8217;s Possible”。  

不知道，新的Logo及标语的更新，是否带来更多的惊喜呢。  

期待中&#8230;

 [1]: http://news.mydrivers.com/img/20070919/02435105.gif