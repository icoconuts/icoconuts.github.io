---
title: Leoparn系列液晶显示器上市
author: elion
date: 2007-09-28T08:34:48+00:00
url: /2007/09/28/leoparnlcd/
views:
  - 170
categories:
  - 折腾二三事
tags:
  - PS作品  
  - hosted-on-yo2
draft: false

---
Leoparn系列液晶显示器上市&#8230;.\*^_^\*  

附海报&#8230;  

<!--more-->

  
声明：本产品纯属虚构，如有雷同，求之不得。  

![][1]

 [1]: http://photo.yo2.cn/photos/56/5562.jpg