---
title: 书：精通CSS：高级Web标准解决方案
author: elion
date: 2007-10-18T08:34:38+00:00
url: /2007/10/18/css-mastery/
views:
  - 89
categories:
  - 分享好玩
tags:
  - 好书分享
  - hosted-on-yo2
draft: false

---

这本是我最近在看的一本还是CSS相关的书籍。  

它有什么特点？  

第一，看书面介绍：  

　■Amazon第一CSS畅销书  
　■最有用的CSS技术汇总  
　■解密业界大师绝技  
够有吸引力吧。<!--more-->

  
第二，简单浏览一下书的内容。  
层次还是很详细的，但给我的感觉是：  
没有想像中的那么高深。  
可能是因为要创新难，学习别人的成果可能会很简单。  
把它介绍给有一定的CSS基础的朋友。

<div class="img_s">
  <img src="http://images.amazon.cn/m/md_bkbk620962.jpg" alt="CSS MASTER" />
</div>

· 开本： 16  
· 出版日期： 2006-11  
· 版次： 2006年11月第1版  
· 页数： 212  
· ISBN： 7115153167  
· 国别： United Kingdom/英国  
· 出版社： 人民邮电出版社  
· 精简装： 平装  
介绍：  
本书将最有用的CSS技术汇总在一起，在介绍基本的CSS概念和最佳实践之后，讨论了核心的CSS技术，例如图像、链接、列表操纵、表单设计、数据表格设计以及纯CSS布局。每一章内容由浅入深，直到建立比较复杂的示例。之后本书用两章讨论招数、过滤器、bug和bug修复，最后由Simon Collison和Cameron Moll两位杰出的CSS设计人员，将书中讨论的许多技术组合起来，给出了两个实例研究。本书还集中介绍了现实的浏览器问题，是弥补CSS知识欠缺不可或缺的参考书。  
　　本书适合具有(X)HTML和CSS基本知识的任何网页设计人员阅读。  
以上书本信息来自joyo。[点我去买书][1]

 [1]: http://www.amazon.cn/detail/product.asp?prodid=bkbk620962&ref=SR&uid=168-5642517-7798653