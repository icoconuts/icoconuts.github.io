---
title: NOKIA音乐手机平面广告
author: elion
date: 2007-11-04T03:29:42+00:00
url: /2007/11/04/nokiaxpress/
views:
  - 253
categories:
  - 分享好玩
tags:
  - 杂文分享
  - hosted-on-yo2
draft: false

---
音符如此震撼，可想而知，音乐会多么美秒。(3Pic)<!--more-->

  
![nokia_1][1] <!--nextpage-->

  
![nokia_2][2] <!--nextpage-->

  
![nokia_3][3]  
试试trackback的评论效果。。:)

 [1]: http://w.886.cn/5tok/52464087/52464087_7190.jpg
 [2]: http://w.886.cn/5tok/52464085/52464085_28374.jpg
 [3]: http://w.886.cn/5tok/52464083/52464083_51324.jpg