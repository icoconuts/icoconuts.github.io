---
title: VS:Silence
author: elion
date: 2008-12-11T11:46:00+00:00
url: /2008/12/11/vssilence/
views:
  - 110
categories:
  - 分享好玩
tags:
  - 主题
  - 美化
  - hosted-on-i815.cn
draft: false
---
  
[Silence][1] by ~[ahlberg][2]{.u} on [deviant][3][ART][3]

很喜欢这个主题的按钮风格，可以借鉴！

 [1]: http://www.deviantart.com/deviation/110166620/
 [2]: http://ahlberg.deviantart.com/
 [3]: http://www.deviantart.com