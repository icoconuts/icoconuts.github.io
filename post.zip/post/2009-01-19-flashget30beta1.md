---
title: Flashget3.0beta1试用
author: elion
date: 2009-01-19T04:49:41+00:00
url: /2009/01/19/flashget30beta1/
views:
  - 520
categories:
  - 分享好玩
tags:
  - 软件分享
  - hosted-on-i815.cn
draft: false

---
不记得还是什么时候用过flashget了，还依稀记得很早以前，用flashget时，它那很有特色的下载分块显示条。

很有意思，但是当时刚出来的迅雷一下子以速度优势把flashget淹没掉了。

随着迅雷的越来越霸道，广告多得让我无法忍受了。 但似乎没有更好的选择，直到看到Flashget3.0preview版的出现，让我非常震撼。

这个感觉就像是当初Theworld2.0Beta出来一样，感觉耳目一新。

我选软件UI一直都是放在第一位的，虽然功能还没有特别完善，但是冲着UI，我已经把迅雷排到第２位了。

安装后，开始把玩起来了。

<!--more-->

![][1] 

上图是主界面，用着相当舒服。看到下载悬浮窗口了么？透明效果。

![][2] 

这个应该是flashget3.0的新特性。

车牌系统，的确是个创新，我觉得这个很有前途，他结合了资源发布的功能，命名为车库，呵呵。

看看我的车牌还不错吧（3连号）。每个新注册用户可以有5次机会。另外通过车币可以再拍车牌。

![][3] 

不过，用一段时间会发现，广告就出来了，虽然可能理解软件本身发展的需要，但希望可以考虑用户的感受。

![][4] 

但是3.0beta版出来后，连可恶的弹出窗口都出来，我真的觉得很心寒。。原来的好感一下子就没了。于是上官网反馈意见。

详见此帖：[http://bbs.flashget.com/viewthread.php?tid=20763][5]

后来，有用户发我一个方法，可以去广告，暂时先这样去广告吧，但是还是希望官方能多考虑考虑用户的想法。

Flashget3.0beta去广告方法：

1)进入安装目录flashgetdatstat，打开stat文件夹。  
2) 将advertisement文件夹删除。然后新建文本文档，将其重命名为advertisement（注意：没有.txt后缀），并设定成只读。

总的来说，flashget3.0将是一个新的开始。

我很看好它。就冲UI，我想一定会关注它从Beta到正式版的发布。

期待。。。

注：更多介绍请点击官方介绍。（很漂亮！）

[http://help.flashget.com/dycsy.html][6]

 [1]: http://farm4.static.flickr.com/3470/3208008337_f875e443bc.jpg
 [2]: http://farm4.static.flickr.com/3321/3208887116_41fa062b14_o.jpg
 [3]: http://farm4.static.flickr.com/3486/3208856458_e03faed8da.jpg
 [4]: http://farm4.static.flickr.com/3367/3208008813_7c8076c5b9_o.jpg
 [5]: http://bbs.flashget.com/viewthread.php?tid=20763 "http://bbs.flashget.com/viewthread.php?tid=20763"
 [6]: http://help.flashget.com/dycsy.html "http://help.flashget.com/dycsy.html"