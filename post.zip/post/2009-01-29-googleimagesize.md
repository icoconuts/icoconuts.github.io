---
title: Google搜索技巧之按尺寸搜图
author: elion
date: 2009-01-29T03:15:31+00:00
url: /2009/01/29/googleimagesize/
views:
  - 165
categories:
  - 分享好玩
tags:
  - Google
  - 技巧收藏
  - hosted-on-i815.cn
draft: false

---

有时候，要找一些特定尺寸的图片，如1024&#215;768,1280&#215;800等等的图片。之前只能按搜索结果中的尺寸寻找，效率太低了。

在Google中试试搜索“[Abstract][1]”，什么尺寸的都有。

现在的方法：

[imagesize:1280&#215;800 Abstract][2]

语法：imagesize: 宽x高 关键词

&#160;

非常方便就能搜索到自己想要的图片了。

&#160;

技巧来自：[Google Operating System][3]

 [1]: http://images.google.com/images?um=1&hl=en&rlz=1C1CHMB_enCN311CN311&q=Abstract&btnG=Search+Images
 [2]: http://images.google.com/images?um=1&hl=en&rlz=1C1CHMB_enCN311CN311&q=imagesize:1280x800+Abstract&btnG=Search+Images
 [3]: http://googlesystem.blogspot.com/2009/01/find-images-that-have-certain-size.html