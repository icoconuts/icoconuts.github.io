---
title: CSS图像热点运用
author: elion
date: 2009-01-31T07:54:13+00:00
url: /2009/01/31/cssimagehotlink/
views:
  - 188
categories:
  - 折腾二三事
tags:
  - CSS
  - hosted-on-i815.cn
draft: false
---
之前有朋友说我的主题像是女生用的，于是新的主题匆忙上马，一直没加上RSS的链接。

因为一直没有什么好的创意，直到前几天在车上想到以拼图的形式实现，回来PS动手一做，感觉瞒好。

&#160;![][1] 

但问题是如何实现链接，本想用土办法，PS制切片，再通过CSS分别定义。

想想没办法解决又放了几天。

<!--more-->

不过一天睡觉前突然想到大学时读过的一本书－－《[CSS Mastery][2]》，有通过运用CSS图像热点实现链接的方法。

![][3] 

效果见右侧侧边栏…

 [1]: http://farm4.static.flickr.com/3459/3240091963_0bd287bf65_o.gif
 [2]: http://www.amazon.cn/detail/product.asp?prodid=bkbk620962&ref=SR&uid=168-5642517-7798653
 [3]: http://farm4.static.flickr.com/3324/3240927170_0affb8386a_o.jpg