---
title: 试试Gmail offline 0.1
author: elion
date: 2009-01-31T10:11:05+00:00
url: /2009/01/31/gmailoffline/
views:
  - 146
categories:
  - 分享好玩
tags:
  - 技巧收藏
  - Gmail
  - hosted-on-i815.cn
draft: false

---
从[CB][1]上得知，Gmail开始支持离线浏览了。这意味着，Gmail已经成为一个离线客户端,您不需要连接到互联网就可以查阅,搜索自己的邮件,并且可以撰写和管理邮件后等待互联网连接上后发送与同步.。

用Gmail offline的前提：

1.已经使用英文Gmail labs。

2.你用的是私人电脑，Gmail会将你所有的邮件和附件保存在本机，部分内容以明文格式保存。

3.选择你最常用的浏览器，Gmail Offline的数据保存，是基于浏览器而不是PC的。

4.该功能需要Google Gear支持。

方法：

<!--more-->

1.打开Gmail，选择Settings,在labs选项里,第一个就是Offline，选择Enable，保存就可以了。

<img src="http://farm4.static.flickr.com/3439/3240245907_42b07952f7_o.jpg" alt="" width="519" width="149" /> 

这里说明一下，好多人都说自己的Gmail里没有这个选项。我一开始也没有，直到在别人的电脑上使用Gmai后，才发现有了。不知道是缓存还是什么原因。如果有同样问题的朋友，使用一下别的电脑，上Gmail试试。

2.回到主界面，右上侧就会出现一个标志，你可以使用Gmail offline的功能了。

![][2] 

3.对Flaky模式的解释

> 在网速不稳定的情况下使用， 在这种情况下，你的工作不受影响，有网则收发，没网则暂存。不管你选择哪种模式，一旦你启用了Gmail Offline之后，你收发的邮件，都会自动同步到本地。

不足：安全性有待加强；不能管理多账户；不能自定义数据保存位置。

附视频解说：

[youtube cOAZaIaeIrI 550 440]

 [1]: http://www.cnbeta.com/articles/75845.htm
 [2]: http://farm4.static.flickr.com/3406/3240257169_a6e08ab25a_o.jpg