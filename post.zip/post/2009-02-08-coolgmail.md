---
title: 超有创意的Gmail介绍
author: elion
date: 2009-02-08T12:59:28+00:00
url: /2009/02/08/coolgmail/
views:
  - 104
categories:
  - 分享好玩
tags:
  - Gmail
  - 视频分享
  - hosted-on-i815.cn
draft: false

---
[youtube d9stAZhbfEE]