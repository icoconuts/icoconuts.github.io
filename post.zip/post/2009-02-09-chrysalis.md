---
title: 泰国潘婷洗发水4分钟足版广告–化蝶(Chrysalis)
author: elion
date: 2009-02-09T11:26:10+00:00
url: /2009/02/09/chrysalis/
views:
  - 211
categories:
  - 分享好玩
tags:
  - 视频分享
  - hosted-on-i815.cn
draft: false
---
[youtube BI2A2_d8CNA 520 350] 

洗发水广告也能拍出这样的励志片，真的很佩服他们的创意。虽然是很老的广告片了，还是分享一下。