---
title: NOKIA N96-BRUCE LEE Edition
author: elion
date: 2009-02-10T13:04:57+00:00
url: /2009/02/10/nokia-n96-bruce-lee-edition/
views:
  - 113
categories:
  - 分享好玩
tags:
  - 视频分享
  - hosted-on-i815.cn
draft: false
---
[youtube DpJAxqD6jiY 520 320]