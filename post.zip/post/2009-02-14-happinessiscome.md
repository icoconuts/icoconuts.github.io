---
title: 《当幸福来敲门》观感
author: elion
date: 2009-02-14T13:50:00+00:00
url: /2009/02/14/happinessiscome/
views:
  - 542
categories:
  - 分享好玩
tags:
  - 影评分享
  - hosted-on-i815.cn
draft: true

---
在订阅的[生活帮][1]里看到这样一篇文章，[从《当幸福来敲门》体会到的几个词 1][2]，让我重新回味了这部电影。

1.幸福

幸福到底是什么？幸福是拥有金钱吗？幸福是没有金钱吗？幸福是拥有家庭吗？幸福是没有家庭吗？都不是。幸福是就是苦尽甘来的瞬间。

没有经历过痛苦，怎么会有甘甜？

试想生活在富裕家庭的人，不会知道当贫穷的人手里拿到1张大钞，就是幸福的。

试想当有人被困孤岛，身边有一大堆的财宝，但这不会幸福，当有船出现时，这才是幸福。(问问海贼王里的山治就知道了。)

电影里有一段主人公的独白：

<!--more-->

That maybe happiness is something that we can only pursue.  
And maybe we can actually never have it&#8230; 

这是他最困苦时候的独白。

他告诉他儿子：

Don&#8217;t ever let somebody tell you,you can&#8217;t do something.not even me.

我想这也是对自己说的吧。

You got a dream, you gotta protect it.  
If you want someting, go get it. 

我们不要去在意别人对自己怎么看～自已应该有自己的目标和方向，我们为自己活着，为自己的家庭活着，为自己认为重要的东西活着，每个人都有自己的幸福，别人是体会不到的。

想想我们自己，我们是否轻易的放弃了，我们羡慕别人的成功，而忽略了走向成功的过程，走在追求梦想的路上是充满挫折的，可幸福和未来也隐藏其中。

<font face="宋体" color="#ff0000" size="4">附上截图及幸福瞬间的视频。</font>

<!--nextpage-->

![][3] 

房东讨房租 <!--nextpage-->

![][4] 

妻子因为他的经济上的无能，选择离开。 <!--nextpage-->

![][5] 

还在帮房东刷房子，但因欠税而拘留，第二天放出，马上奔去面试。 <!--nextpage-->

![][6]![][7] 

没地方住，住在地铁的厕所，如果自己带着孩子身处此所，再坚强的人也要默默流泪了。 

<!--nextpage-->

  


<embed src="http://player.youku.com/player.php/sid/XNzIxMjQyNjA=/v.swf" quality="high" width="520" height="420" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>

  
当得知自己成为实习生中唯一一位留下来工作的消息后，看看威尔史密斯如何诠释幸福。

 [1]: http://www.lifebang.com/
 [2]: http://www.lifebang.com/archives/503
 [3]: http://farm4.static.flickr.com/3345/3278069327_7324d300aa.jpg
 [4]: http://farm4.static.flickr.com/3468/3278069661_12a7239e09.jpg
 [5]: http://farm4.static.flickr.com/3448/3278069475_87fb53c21c.jpg
 [6]: http://farm4.static.flickr.com/3475/3278069795_b574b4554a.jpg
 [7]: http://farm4.static.flickr.com/3473/3278069111_c3a2a566c6.jpg