---
title: Gravatar注册教程
author: elion
date: 2009-02-17T14:13:51+00:00
url: /2009/02/17/gravatarsignup/
views:
  - 397
categories:
  - 折腾二三事
tags:
  - Gravatar
  - hosted-on-i815.cn
draft: false
---
<a href="http://en.gravatar.com/" target="_blank">Gravatar</a> (Globally Recognized Avatar的缩写)，意思就是全球认证头像（全球通用头像）。它是由WordPress系列产品的母公司Automattic运营的一个面向广大博客网站提供通用头像服务的网站。在该网站注册账户并上传头像以后，在全球任意一个支持Gravatar的网站（如基于WordPress的大部分博客），在评论时只要输入您的电子邮箱，在评论旁即可显示您的个性头像。你注册一个帐号后，可以添加多个邮件地址和对应头像。

===============================================================================

自WordPress升级到 2.5版本以后，WordPress内置显示Gravatar的头像的功能。这里就简单说一下主题添加此功能的方法： 

1.Gravatar参数：

> <?php [echo][1] get_avatar( $comment, 32 ); ?> 

2.找到主题目录下的comments.php文件，打开后找到相关代码插入就可以了。

注意：该函数的调用须放在<?php foreach ($comments as $comment) : ?>语句后，否则会出错。

具体方法，可以参看这篇文章－－<a href="http://www.thinkagain.cn/archives/904.html" target="_blank">WordPress Tips:如何使用WP2.5内置的Gravatar</a>。

===============================================================================

Gravatar注册很简单，不懂英文也不用觉得麻烦的。几步就可以实现注册。

<!--more-->

1.登陆<a href="http://en.gravatar.com/" target="_blank">Gravatar</a>,点<a href="http://en.gravatar.com/signup" target="_blank">Sign up now!</a>,进行注册。

2.然后会进入一个页面，需要你输入Email地址，输入后，会向你的邮箱里发一封确认信。

3.打开收到的Gravatar的确认信，有一个确认链接，打开确认链接。

4.打开后，输入用户名和密码，注意，名字不能大写，而且不能跟别人注册的名字重复，否则无法注册成功的。

5.注册完毕。

===============================================================================

Gravatar的使用：

1.登陆<a href="http://en.gravatar.com/" target="_blank">Gravatar</a>，点<a href="http://en.gravatar.com/site/login/" target="_blank">Log in</a>,登陆。

2.上传头像，上面有个My Account按钮，选择Add an Image，然后会出现3个选项

&#160;&#160;&#160; a,从本地电脑中选择图片

&#160;&#160;&#160; b,从互联网上选择图片

&#160;&#160;&#160; c,使用摄像头截取图片

&#160;&#160;&#160; d,使用之前上传过的图片(这个第一次使用应该没有。)

一般选择第一种。你可以先用PS简单编辑一下你想使用的图片(一般做成120X120的够了，谁会把头像尺寸设这么大？)，然后再上传。

注意：如果从电脑中选择图片，图片格式只能为jpeg,gif或者png。

3.图片上传后，点“在线截取”(如果之前已经PS做好，请直接全部截取)，右面有实际效果图。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3526/3287076377_a9ea210e56.jpg" /> 

8.头像上传后，图片要分级的，选择你上传的图片的级数，一般的，选G级，也就是大众都可以看的。

9.头像设置，直接在你的头像列表里选择就可以了。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3604/3287905832_16d6b328e4.jpg" /> 

&#160;

10.<font size="6">完.</font>

=============================================================================== 

一些关于Gravatar的常见问题：

  1. **1.问：注册Gravatar之后，只要是WordPress博客就能看到自己的头像了么？**  
    答：不一定，这取决于博客主题是否支持了Gravatar的API，幸运的是，目前大多数WordPress博客所使用的主题是支持Gravatar的。 
  2. **2.问：只能在WordPress博客使用Gravatar么？**  
    答：不是。这主要取决于网站管理者：只要网站能获取你的EMail信息，同时又在展现层使用Gravatar的API，就可以使用。国外一些小的Web2.0公司的产品都是支持Gravatar的。 
  3. **3.问：用EMail去匹配，又是通过展现层（HTML代码），那会不会泄露我的EMail呢？**  
    答：不会，因为Gravatar使用的是MD5加密之后的EMail字符串，您完全不必担心您的EMail地址泄露。 
  4. **4.问：为什么我注册之后看不到图像？**  
    答：因为Gravatar有一个比较长的缓冲周期；注册完之后，并不会立即显示相应图像 
  5. **5.问：我如果现在注册，之前留言中的头像会显示么？**  
    答：会，只要你使用了同样的EMail地址。 
  6. **6.问：如果想注册多个头像，怎么办？  
** 答：可以用Gmail的一个“加号”小技巧来注册。其他邮箱暂时无法满足这种需求。 
  7. **7.问：如果有人冒充我的邮箱呢？**  
    答：没办法，如果被人冒充，就会显示这个邮箱匹配的头像，这的确是一个问题。因此，保护好自己的邮箱是非常重要的，如果你使用Gmail的话，你可使用yourmailname+XXXATgmail.com来作为你的注册邮箱。一般人是无法猜测到你这个“+XXX”的私有后缀的，而这个邮箱又能在Gmail所正常使用。

 [1]: http://www.php.net/echo