---
title: 主题完善之一
author: elion
date: 2009-02-27T14:06:18+00:00
url: /2009/02/27/redesignrs/
views:
  - 115
categories:
  - 折腾二三事
tags:
  - 主题制作
  - WordPress
  - hosted-on-i815.cn
draft: false
---
之前为“最新日志/最新评论”设置的右侧侧边栏动态显示效果，用了一段时间感觉不太舒服

想想还是转回原来的效果：在页面底部并排显示。虽然不是我自己的创意，但还是自己通过CSS慢慢调整得出了。

本效果在IE 7,chrome,Firefox,Opera下测试通过，至于IE 6不做考虑。。

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3585/3313305807_e48bf7bb6b_o.jpg" /> 

<!--more-->

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3495/3313306153_e3ee8ba36d_o.jpg" />