---
title: 女士们注意了:红色的 MacBook Mini
author: elion
date: 2009-03-03T14:13:15+00:00
url: /2009/03/03/red-macbook-mini/
views:
  - 671
categories:
  - 分享好玩
tags:
  - macbook
  - 好物分享
  - hosted-on-i815.cn
draft: false

---
Apple 推出震撼全球的产品 &#8211; MacBook Mini。更耀眼的是，它是红色版本的！  
这台 MacBook Mini 的大小与 Vaio P 相若，特别是拥有滑盖式的触控板。  
因此，这部 MacBook Mini 可以拥有全尺寸的键盘及触控板。  
P.S.　这台 MacBook Mini 是设计师 Isamu Sanada 的构想图，所以这个不是真的，也不是 Apple 发布的新产品。  
点击看图&#8211;><!--more-->

  
本文转自:[Engadget][1]  
![][2]  
<!--nextpage-->

  
![][3]  
<!--nextpage-->

  
![][4]  
谢谢欣赏。

 [1]: http://cn.engadget.com
 [2]: http://www.blogcdn.com/chinese.engadget.com/media/2009/03/red_fake_macmini_11.jpg
 [3]: http://www.blogcdn.com/chinese.engadget.com/media/2009/03/red_fake_macmini_21.jpg
 [4]: http://www.blogcdn.com/chinese.engadget.com/media/2009/03/red_fake_macmini_31.jpg