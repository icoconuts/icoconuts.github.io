---
title: Lancome Magnifique–兰寇璀璨香水广告
author: elion
date: 2009-03-08T12:33:54+00:00
url: /2009/03/08/lancome-anne/
views:
  - 581
categories:
  - 分享好玩
tags:
  - 视频分享
  - hosted-on-i815.cn
draft: false
---
[Youtube视频已经被墙,换成youku了。]  


<embed src="http://player.youku.com/player.php/sid/XMTYxMTA4MDMy/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>

Anne Hathaway，我个人认为她是个很高贵，很有气质的女星。

也许是因为那部《The Devil Wears Prada》的缘故吧。

最近看了一部她的新作《Rachel Getting Married》，形象180度大转弯。。

那天在半夜实在是看不下去了。。唉~~不说了~~

另外第二页附上这个广告的制作花絮~~

<!--nextpage-->[youtube SI4uywR_EPc] 

谢谢欣赏。