---
title: '<转>RSS feed 摘要输出轻松全文'
author: elion
date: 2009-03-17T04:46:02+00:00
url: /2009/03/17/all-rss-feed/
views:
  - 277
categories:
  - 折腾二三事
tags:
  - Google reader
  - hosted-on-i815.cn
draft: false

---
在小众软件上刚看到的一篇文章，转一下。

最强最傻瓜化的 RSS feed 全文化利器：まるごとRSS。只需把博客的地址或者 RSS feed 输入到页面唯一的输入框里，然后点击 Go，全文化的 Feed 就生成了！看下图，页面还生成了相应的订阅按钮。赶紧点击 Googleリーダー，订阅到 Google Reader。注意，第一个按钮是 iGoogle。

<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://pic.yupoo.com/jdvip/95911721d3ef/small.jpg" alt="" width="191" height="240" />
</p>

<p style="text-align: center;">
  <!--more-->
</p>

为什么选择 Google reader 作为阅读器？免费强大好用，能通过 https 方式访问，不用担心被 GFW 过滤。延伸阅读：RSS 阅读器，价值几何。  
生成的全文 Feed 效果如何？来看 Cnbeta Feed（其官方 feed 是摘要的） 对比图：上部是全文 CnBeta Feed （好像用 Pipes 生成）的一篇只有标题的文章，此全文 Feed 还是不够完美，有一些文章只输出了标题。下部是用まるごと RSS 生成的对应全文。图文并茂，缺点就是标题重复了，还有发布者发布时间也被抓取了。CnBeta 的全文 Feed 我就不写出来了，大家自己用 まるごとRSS 试试看吧。Pipes 这样强大的利器还是给不折腾会死星人去用吧。

<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://pic.yupoo.com/jdvip/99335721d3ef/medium.jpg" alt="" width="236" height="240" />
</p>

我还测试了一个百度博客的 Feed，也成功了。不过连评论也一并抓取了。检查了其最新的十篇文章的全文状态，发现其中有两篇文章全文失败，这是因为原文的 Html 代码有问题。成功率还是比较高的说，失败了也没什么补救的方法。  
当然这个网站并不是全能的，有些摘要 Feed 可能无法全文化。

原文链接：<http://www.appinn.com/full-rss-feed/>