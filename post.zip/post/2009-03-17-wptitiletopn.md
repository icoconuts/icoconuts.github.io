---
title: WP插件:让你的图片签名显示日志更新
author: elion
type: post
date: 2009-03-17T13:12:54+00:00
url: /2009/03/17/wptitiletopn/
views:
  - 291
categories:
  - 折腾二三事
tags:
  - WordPress
  - hosted-on-i815.cn
draft: false
---
插件功能介绍：生成一个论坛签名图片，在该图片上自动显示你的Wordpress博客上的最新文章。  
把blog文章列表生成图片的插件。

效果预览：

<img class="alignnone" src="http://127.0.0.1/tool/title.png" alt="" /> 

<!--more-->

  
安装步骤：  
1：下载该插件 1.0版：<http://titletopng.googlecode.com/files/titletopng.rar>  
2：解压缩后传到你的wordpress程序的/wp-content/plugins/ 目录下  
3：将/wp-content/plugins/ 目录下的 titletopng目录权限设为777 （即让该目录可写 WINDOWS服务器请忽略该步）  
4：在后台插件管理处选择开启”图片签名插件”  
5：在后台设置处选择title2png进行设置  
6：/wp-content/plugins/titletopng/title.png 即为生成后的图片文件，在论坛签名中请用如下代码][img]http://www.px234.cn/wp-content/plugins/titletopng/title.png[/img]  则可自动显示你的Wordpress最新文章了。

常见问题

1：如何修改背景图片

请用你的PNG格式的图片替换掉插件目录下的pic.png 文件

1：如何修改字体?

用你的字体文件替换掉本插件目录中的msyh.ttf文件即可

2：如何修改字体颜色？

在后台设置中只有3组数字供大家设置，大家肯定不知道哪些数字表示什么颜色，这就需要大家用一些画图工具了，用photoshop等来查询就可以了，也有一些在线工具但是蜗牛我还没找到

3：如何定位文本块开始的坐标？

同上，还是要用到画图工具，要么大家就慢慢试

4：怎么生成不了图片？

请检查你的插件目录权限，若没开启写权限的话，则图片无法生成。

－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－

使用后感觉，希望插件能有以下改进：

1.字体问题，如何不使用字体，插件就会无法正常运行。

2.图片引用问题，如果某个论坛流量比较大，那服务器就有点压力了。

3&#8230;暂时没有了。想到再讨论。  
原文地址：<http://www.px234.cn/titletopng>