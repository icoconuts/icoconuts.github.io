---
title: 插件Titletopng-DIY
author: elion
type: post
date: 2009-03-20T10:49:06+00:00
url: /2009/03/20/titletopng-diy/
views:
  - 296
categories:
  - 折腾二三事
tags:
  - WordPress
  - hosted-on-i815.cn
draft: false

---
前几天找到了一款很有意思的插件：<a href="http://127.0.0.1/2009/03/17/wptitiletopn/" target="_blank">titletopng</a>。它可以让blog更新信息显示在任何可以贴图的地方。（如论坛签名。）

今天有时间，好好把玩了一下。

效果预览：

![][1] 

<!--more-->

首先，在作者的博客上发现有更新了：

> 版本1.1&#160; 更新时间:2009-03-14
> 
> 更新日志： 增加了用户自定义图片的输出路径
> 
> 更新文件下载地址 [updatato11][2] 

&#160;

插件构成很简单:index.php,pic.png(原背景图),msyh.ttf(字体文件&#8211;雅黑字体)。

1.个人不太喜欢雅黑字体，可能有点审美疲劳了吧。

为了以后更换字体方便，先打开index.php，查找msyh.ttf,替换成font.ttf.

这样以后更换字体，只要将所需的字体文件名改成font.ttf就可以了。

2.打开PS，发挥自己的想像吧，PS出一张修改的背景图片，配上字体和字样。

这样方便后面设置。

注意：制作的图片尺寸，尽量长而扁，适合做论坛签名图片。

制作成的图片覆盖pic.png就可以了。

3.后台设置

插件比较人性化，后台设有预览功能，大家可以根据制作的图片直接调试。

以下是我的设置：

显示文章数: 5篇  
字体大小: 10 px  
标题长度:60 字节  
行间距: 10 px  
文本块开始处的横坐标:13 px  
文本块开始处的纵坐标:22 px  
文本颜色: 255 255 255

至于图片输出路径，我直接放在根目录下，这样方便引用。

&#160;

附上我用的字体和图片的PSD源文件！

字体：<a href="http://www.box.net/shared/i500o9afhs" target="_blank">方正少儿字体</a>

PSD源文件：[download id=&#8221;16&#8243;]

 [1]: http://127.0.0.1/tool/title.png
 [2]: http://www.px234.cn/wp-content/uploads/2009/03/updatato11.rar