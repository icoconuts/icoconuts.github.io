---
title: Web2.0时代,你玩Twitter了吗?
author: elion
date: 2009-03-29T12:11:47+00:00
url: /2009/03/29/twitter-intro/
views:
  - 485
categories:
  - 分享好玩
tags:
  - twitter
  - 新闻分享
  - hosted-on-i815.cn
draft: false

---
![][1]

什么是Twitter

&#160;&#160;&#160; Twitter 是即时信息的一个变种，它允许用户将自己的最新动态和想法以短信息的形式发送给手机和个性化网站群，而不仅仅是发送给个人。

&#160;&#160;&#160; Twitter是一个可让你播报短消息给你的朋友或“followers（跟随者）”的一个在线服务，它也同样可允许你指定哪个你想跟随的Twitter用户，这样你可以在一个页面上就能读取他们发布的信息。所有的Twitter消息(tweet)都被限制在140个字符之内。这也是Twitter迷人之处的一部分。

Twitter的创立

&#160;&#160;&#160; 2006年，博客技术先驱blogger.com创始人埃文·威廉姆斯(Evan Williams)创建的新兴公司Obvious推出了Twitter服务。

注册Twitter

<!--more-->

&#160;&#160;&#160; 非常简单：直接登陆<a href="https://twitter.com/signup" target="_blank">Twitter的注册页面</a>,注意Full name到是无所谓，关键是Username，这个就是你注册后显示的名字以及网址。本想注册elion这个名字的，但已经被注册掉了，无奈之下，只能选择elion815了，所以，我的Twitter的地址就是：<a href="http://twitter.com/elion815" target="_blank">http://twitter.com/elion815</a>.

注册后，你该了解到的信息：

&#160;&#160;&#160; 在你的Twitter页面上有一些数字，这些都是非常重要的描述：

1、followers前面的数字表示有多少人正在跟随（follow）你。

2、friends前面的数字表示你跟随(follow)了多少人。

3、Direct Messages前面的数字表示你接收到了多少来自于朋友的直接发送的消息，点击该链接就可查看到这些消息的详情。

4、Favorites前面的数字表示你收藏了多少条目，点击该链接就可看到每条收藏条目。我们可以看到，在每条消息后面都有一个“星号”“图标，当点击该星号后说明这条消息就是你收藏的了。

5、Updates前面的数字表示你发送过多少条消息。</p> 

&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;-

我的Twitter:<a href="http://twitter.com/elion815" target="_blank">elion815</a>,欢迎Follow~~

 [1]: http://assets1.twitter.com/images/twitter_logo_s.png