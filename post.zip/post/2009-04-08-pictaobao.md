---
title: 淘宝店家宝贝的照片
author: elion
date: 2009-04-08T05:19:45+00:00
url: /2009/04/08/pictaobao/
views:
  - 444
categories:
  - 分享好玩
tags:
  - 暂无分类
  - hosted-on-i815.cn
draft: false

---
在淘宝逛了很久了，一直是为了买东西去逛，去找。前段时间买得非常疯狂。

现在似乎是静下来了，但偶尔会漫无目的地去逛逛&#8230;

尤其昨天为了买手机，点了无数网页，不知道点错了还是什么，竟点到一个女装的店里去了。

对商品到没什么感觉，不过对这照片的拍摄效果还是瞒喜欢的。

个人觉得买同样的东西，我一定会先选这家，也许是同样的商品，但给人的感觉，品味就不同。

嗯，随便挑几张拍得不错的宝贝照片~~

<!--more-->

还有第2页

<img loading="lazy" class="alignnone" src="http://mixico.com.cn/2009_tee/4/2009_4_8_05_01.jpg" alt="" width="513" height="387" /> 

 

<img loading="lazy" class="alignnone" src="http://mixico.com.cn/2009_tee/4/2009_4_03_01_05.jpg" alt="" width="513" height="387" /> 

 

<img loading="lazy" class="alignnone" src="http://mixico.com.cn/2009_tee/3_27/2009_4_1_04_01.jpg" alt="" width="513" height="387" /> 

 

<img loading="lazy" class="alignnone" src="http://mixico.com.cn/2009_tee/3_27/2009_03_027_03_1.jpg" alt="" width="513" height="387" /> 

 

 

<!--nextpage-->

<img loading="lazy" class="alignnone" src="http://up8.babidou.com/pic/2007/6/5/zz577993/5872er.jpg" alt="" width="520" height="520" /> 

 

<img loading="lazy" class="alignnone" src="http://www8.babidou.com/pic/2007/6/5/zz577993/7167b.jpg" alt="" width="517" height="229" /> 

 

<img loading="lazy" class="alignnone" src="http://www8.babidou.com/pic/2007/6/5/zz577993/7065f.jpg" alt="" width="517" height="229" /> 

完