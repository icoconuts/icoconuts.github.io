---
title: 翻翻我的博客情结
author: elion
date: 2009-04-21T12:18:57+00:00
url: /2009/04/21/mytripofblog/
views:
  - 368
categories:
  - 折腾二三事
tags:
  - 杂文
  - 建站相关
  - hosted-on-i815.cn
draft: false

---
今天中午，朋友问我哪有博客可以申请，这倒一下子提醒我了。

以前一直想从之前的博客上把日志转过来，毕竟是自己的心路历程啊。

于是把自己之前用过的博客网站告诉了她，然后自己去把之前的日志转过来了。

中午转好日志后，下午上班一直在回忆自己的走过的博客之路。

晚上一回来，就整理+回忆。

&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;

我是个怀旧的人！！！

现在开始吧。

1.Msn spaces

MS那个时候，正是博客时代的开端吧。

喜欢她的柔和，也正是从那时开始就去“研究”博客的美化了。今天，再上过去，速度依旧，日志依旧。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3563/3461788735_f6da5e411a.jpg" /> 

2005.6.25

用了差不多一年，速度慢得有点受不了。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3562/3462604708_3e9b8b0b4f.jpg" /> 

2006.6.25

1-1.Blogcn

一个特殊的博客

我竟然还记得网址。发现我很强！！

用了没久就不了了之了，现在只剩下这几偏日志在网络上飘~~

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3557/3461788685_3107fd150d_o.jpg" /> 

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3521/3462604876_eb0ec7100c_o.jpg" /> &#160;

2.Opera Blog

从那时候开始，开始去混先锋，极限，正当Msn spaces越来越慢的时候，大家开始推荐用Opera Blog。那速度真是快的，soso的。

那段时间尝试简单修改背景，制作自己的DIY主题，比较得意的就是那个古镇风格的主题。

到现在看看还是这么的舒服。可是就在使用Opera Blog的喜悦之下，突然，有一天，它不能访问了。

也从那时知道了GFW这个词的含义了！！！我那个恨啊！！含泪相别啊。

今天，通过FF翻墙过去，那个博客依旧还在…

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3492/3462604806_444ed680fa.jpg" /> 

&#160;

发现一篇日志。。关于iphone的，多久前就关注啦，现在还是没有买到她。唉~~

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3516/3461788919_f746dcf1a8_o.jpg" /> &#160;

3.BlogBus

BlogBus，在美化界似乎很流行，也许是因为天气雨的缘故吧，那段时间，估计有一大批的人去那里注册了博客。

说实话，BlogBus速度很不错，自定义也很强。

我用了也有一段时间，只是后来发现，广告很不爽。而且渐渐地认识了WordPress。之后，也离开了BlogBus。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3651/3462611976_b3843061b3.jpg" /> 

&#160;

4.yo2

WordPress的BSP，同样，从Yo2,熟悉了WordPress，那段时间，慢慢了解了WordPress，个人感觉做了几个不错的主题，可惜yo2的WordPress升级后，原主题丢失，现在只剩下默认主题了。

至于为什么离开，还是因为自定义性不够强，上传主题很容易出现问题，而且有广告，绑定域名也要钱。最后，选择自己动手，找空间，自己架博客。

哦，对了，那时候用alimama的广告，赚了30元钱。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://farm4.static.flickr.com/3636/3462612014_bc2efdc864_o.jpg" /> 

&#160;

5.国外免费空间+elion86.cn

自离开yo2后，从<a href="http://www.webhosts4free.com/" target="_blank">webhosts4free</a>、<a href="http://www.free-webhosts.com/" target="_blank">free-webhosts</a>注册了N多免费空间，另外买了个域名，1RMB，然后开始自己架博客。

不过由于国外免费空间的不稳定和速度时快时慢，最终也就结束了。之前备份的日志在原来的电脑，现在也无法截图。

不过通过那段时间，更加坚定了自己架博客的决心，因为这样无束缚。也体现了DIY的精神。呵呵~~那时候也做了一个自认为不错的主题。

&#160;

6.i815.cn至今

这个域名想了很久，最终还是以自己的生日命名了。1元搞定。

另外，在淘宝上买了空间。20元/年。

付费空间，应该不错吧。这点钱，我觉得应该值的吧。

我想，我会坚持用这个空间。除非，除非，它不存在了。那我要哭死。

嗯，对了，这个主题不会用太久了，太多太多的朋友，对这个灰色，提出了很大的意见。。。