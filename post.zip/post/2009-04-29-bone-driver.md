---
title: 新奇可爱–台湾Bone系列U盘
author: elion
date: 2009-04-29T05:05:33+00:00
url: /2009/04/29/bone-driver/
views:
  - 1409
categories:
  - 分享好玩
tags:
  - U盘
  - 好物分享
  - hosted-on-i815.cn
draft: false

---
自从上海回来丢了U盘，我不得不考虑这回要买一个不会再丢的U盘了。

回想造成U盘丢失的原因：

1.都是放在口袋里，或是随便扔在某个角落里了。

2.认为是便宜货，随处扔。

现在买了三三，想买一个小巧好看的U盘挂在手机上。

前几天在桐城上看到一篇文章。介绍新奇U盘的。这几天找了一下，确实很不错。

但是有点贵。。。。。

先看看BONE的品牌：

> BONE品牌精神
> 
> 逃离单调 创意生活
> 
> 没有人在乎我们的世界塞满了东西，  
> 生活的灵感没办法起作用，因为那些东西是…&#8221;单调&#8221;。  
> 我们塑造了Bone，是要打开通往新世界的门，  
> 让逃离&#8221;单调&#8221;的想法弥漫在生活里的每个角落。
> 
> Bone希望创造一些人们真正想要的东西，  
> 跳脱平凡的想法，重组每天生活的心情，  
> 加入一些设计的趣味让心跳加速，唤醒对生活的感受。
> 
> 当体验到的时候并不只是发出第一个惊呼声而已，  
> 在持续的体验中你会慢慢感受到生活改变的不同，而这是一个美好的感觉！  
> 这就是我们说的&#8221; Bone your Life， be Different &#8220;，等你来体验！
> 
>  

好了，上图。（我不是做广告的，但感觉像是给这个牌子做广告了。）

先说一句，都很可爱，但也都很贵。。。o(╯□╰)o

<!--more-->

1.Pod Driver

<img loading="lazy" src="http://www.qunlou.com/tb/bone-ipod-black-2g-2.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/bone-ipod-white-1g-3.jpg" alt="" width="480" height="360" /> 

 <!--nextpage-->

2.Iphone Driver

<img loading="lazy" src="http://www.qunlou.com/tb/bone-iphone-2g-1.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/bone-iphone-2g-4.jpg" alt="" width="480" height="360" />    
<!--nextpage-->

  
3.Tail Driver

<img loading="lazy" src="http://www.qunlou.com/tb/bone-tail-red-2g-3.jpg" alt="" width="480" height="360" /> 

   
<!--nextpage-->

  
4.Doggy Driver<img loading="lazy" src="http://www.qunlou.com/tb/bone-tail-red-2g-5.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/bone-dog-2.jpg" alt="" width="480" height="360" /> 

  <!--nextpage-->

5.Open Driver <img loading="lazy" src="http://www.qunlou.com/tb/opendriver_3.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/opendriver_2.jpg" alt="" width="480" height="360" />  
<!--nextpage-->

  
6.Penguin Driver

<img loading="lazy" src="http://www.qunlou.com/tb/bone-penguin-coat-2.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/bone-penguin-2.jpg" alt="" width="480" height="360" /> 

<!--nextpage--> 

7.Panda Driver

<img loading="lazy" src="http://www.qunlou.com/tb/bone-panda-2g-4.jpg" alt="" width="480" height="360" /> 

 

<img loading="lazy" src="http://www.qunlou.com/tb/bone-panda-2g-3.jpg" alt="" width="480" height="360" />