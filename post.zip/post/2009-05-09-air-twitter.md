---
title: 三款基于Adobe AIR的Twitter客户端
author: elion
type: post
date: 2009-05-09T10:21:27+00:00
url: /2009/05/09/air-twitter/
aktt_notify_twitter:
  - no
views:
  - 814
categories:
  - 折腾二三事
tags:
  - twitter
  - hosted-on-i815.cn
draft: false

---
前面介绍过<a href="http://127.0.0.1/2009/03/29/twitter-intro/" target="_blank">Twitter</a>， 但由于Twitter的<a href="http://twitter.com/elion815" target="_blank">网页版</a>功能太过简单，甚至连基本的RT都没有，非常的不方便。

在Twtitterr的第三方软件中，我试用过许多，觉得还是基于Adobe AIR的工具最方便，功能也强大。

要安装AIR程序，就必须安装<a title="点击下载" href="http://www.adobe.com/cn/products/air/" target="_blank">Adobe AIR</a>。  
AdobeR AIR™ 是跨作业系统的执行阶段, 可让开发人员使用熟悉的网页工具, 包括 HTML、Ajax、Adobe FlashR 和 Adobe FlexR 来建立可部署至桌面的多样化网际网路应用程式 (Rich Internet Applications)。有了 Adobe AIR, 开发人员就可以运用现有的技巧和工具来建立引人入胜的视觉化多样化应用程式, 兼具桌面的丰富体验与网路的广泛触及性的优点。

&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8211;

1.<a href="http://www.twhirl.org/" target="_blank">Twhirl</a>

Twhirl在Twitter的第三方软件里，应该算是大名鼎鼎了。关于它的介绍也是到处都是。

<!--more-->

到目前的最新版是<a href="#download" target="_blank">0.9.2版本</a>。

主要特点：

    更新信息通知功能

  *     短网址功能(新增<a href="http://digg.com" target="_blank">digg.com</a>,<a href="http://bit.ly" target="_blank">bit.ly</a>, [twurl][1] 或 [is.gd][2] )
  *     可从Twitter 直接更新到 [Pownce][3] 和 [Jaiku][4]
  *     可发布图片到 [TwitPic][5]
  *     可通过[Twitter Search][6] 和[TweetScan][7] 搜索Tweets 信息
  *     时间线过滤功能
  *     支持皮肤切换
  *     自动检查新版本 使用感受：（1）虽说许多人说这个界面很漂亮，但我却没发现它哪里漂亮了！（2）功能的确很强大。 
    （3）新信息到达有声音提示，觉得瞒好的。
    
     </li> </ul> 
    
![][8] 
    
     
    
    2.<a href="http://www.tweetdeck.com/" target="_blank">TweetDeck</a>
    
    TweetDeck虽然在Twitter官方的APP里没有做出链接，但它的口碑还是相当不错的。
    
    到目前还是beta版本，最新版是<a href="#download" target="_blank">0.25Beta版本</a>。
    
    第一次看到TweetDeck，就被它的美观所吸引，所以就想无论它是空壳或是功能欠缺，我也不想再用Twhirl了。（个人对外观的要求大于功能。）
    
    不过，刚用上就出现个麻烦事，不显示中文，还好摸索了一下，发现个有选项可以设置。
    
    试用几天后，才发现，它的功能也不亚于Twhirl。
    
    如今0.25版本，又加入了一些功能，如直接在软件中显示twitpic的缩略图、录音功能、缩略网址的预览功能。
    
     
    
    使用感受：
    
    （1）界面很漂亮，没得说，显示也比Twhirl流畅！
    
    （2）新版功能很强大。
    
    （3）整体界面太大了，就算只显示单栏，也感觉有点大（引出第3个工具，o(∩_∩)o&#8230;）。
    
     
    
    预览图：
    
![][9] 
    
     
    
    点选这个，才能显示中文。
    
![][10] 
    
     
    
    3.<a href="https://destroytwitter.com/" target="_blank">DestroyTwitter</a>
    
    DestroyTwitter相比于前两位，名气肯定小许多。
    
    不过作者名字取得相当有自信，他还有<a href="http://www.destroytoday.com/projects/destroyflickr" target="_blank">DestroyFlikr</a>,也一款非常优秀的作品。
    
    如果说用“华丽”来形容TweetDeck，那么DestroyTwitter就用“小巧”来形容。
    
    到目前还是beta版本，最新版是<a href="#download" target="_blank">1.6.0 Beta版本</a>。
    
    同样,DestroyTwitter默认也不显示中文，通过以下设置，便可以正常显示中文了。
    
    DestroyTwitter的更新速度很快，记得第一次使用的版本，也就在1，2个月前吧。
    
    那时候，不支持缩略网址的选择，不支持twitpic等等。
    
    现在这些功能都已经加上。
    
     
    
![][11] 
    
     
    
![][12] 
    
     
    
    使用感受：
    
    （1）界面很小巧简洁，连标题栏也实现了统一，当然也可以通过设置显示系统主题。
    
    这也是我一直用这款工具的理由！
    
    （2）各面板间切换，包括参数设置面板的切换，效果做得很流畅，体现出了基于flash的特色。
    
    （3）功能基本全面，期待增强！
    
    小结：
    
    总的来说，我现在用DestroyTwitter和Tweetdeck更多一点。期待DestroyTwitter的功能再加强一点，这样，基本就全用DestroyTwitter了。
    
    Twitter的第三方工具实在是有太多太多，我也只是就我用过的基于AIR平台的第三方软件做个介绍。有喜欢的，可以再找找。
    
     
    
    这三款软件的下载地址：
    
    <p id="download">
      Twhirl下载:<a href="http://d.seesmic.com/twhirl/twhirl-0.9.2.air" target="_blank">0.9.2</a>
    </p>
    
    TweetDeck下载:<a href="http://www.tweetdeck.com/beta/" target="_blank">0.25Beta</a>
    
    DestroyTwitter下载：<a href="http://www.destroytoday.com/releases/DestroyTwitter160B.zip" target="_blank">1.6.0Beta</a>

 [1]: http://tweetburner.com/
 [2]: http://is.gd/
 [3]: http://pownce.com/
 [4]: http://www.jaiku.com/
 [5]: http://twitpic.com/
 [6]: http://search.twitter.com/
 [7]: http://www.tweetscan.com/
 [8]: http://lh5.ggpht.com/_ppBg9KfFNCQ/SgU1AWK6NII/AAAAAAAAApQ/DmNhHdGu2Sg/s800/05-09_1530.jpg
 [9]: http://lh5.ggpht.com/_ppBg9KfFNCQ/SgU4YM8HZnI/AAAAAAAAApU/X8KrvKrjV8g/s800/05-09_1558.jpg
 [10]: http://lh5.ggpht.com/_ppBg9KfFNCQ/SgU4Z66o5zI/AAAAAAAAApY/0tj7F2PA614/s800/05-09_1600.jpg
 [11]: http://lh4.ggpht.com/_ppBg9KfFNCQ/SgVYHVKVBSI/AAAAAAAAAp0/jdRIXGmjDnw/s800/05-09_1810.jpg
 [12]: http://lh6.ggpht.com/_ppBg9KfFNCQ/SgVYJZO7NSI/AAAAAAAAAp4/Ut6GRmtluqE/s800/05-09_1642.jpg