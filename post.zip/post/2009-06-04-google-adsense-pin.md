---
title: Google AdSense的信件终于到了
author: elion
date: 2009-06-04T13:41:18+00:00
url: /2009/06/04/google-adsense-pin/
views:
  - 335
categories:
  - 生活记事
tags:
  - 日记
  - hosted-on-i815.cn
draft: false

---
盼了一个多月，Google AdSense寄来的PIN码确认信件终于到了。

早上同事告诉我说你美国寄来的美元到了，我以为他骗我，因为寄来的根本不是美元。

不过他说是薄薄一张纸，这倒说对了。

下楼到值班室一看，果然有信。

说实施，挺激动的。

1.咱乡下来的，第一次收到外国寄来的信件。

2.信的风格还是秉承Google一贯的风格&#8211;简洁。

不知道是不是自己已经成为“狗饭”了。

平时在电脑前看Google的标志觉得没什么特色。

但今天看到信件背面Google的标志，觉得很舒服，颜色搭配好恰到好处。

品牌的形象看来已经深入我心了。

以后打算多关注下Google logo标签贴的活动，有冲动就去买。

&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;-

PIN码在Google Adsense帐号下确认后，就可以实现付款了。

现在离$100美元还有很大的距离，不过自己开博客仅仅只是当自己的窝。

完全不是为了赚这个小钱，只是觉得想尝试一下Google Adsense这个服务。

嗯，不过玩笑的说，这第一笔小钱，我已经想好买什么了。哈哈~~

最后附上几张信件的照片。

希望通过搜索搜到我这篇日志的朋友能先看看这个信件的样子而已。

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://lh4.ggpht.com/_ppBg9KfFNCQ/SifONznB14I/AAAAAAAAA1E/T-4nwkHPyBI/s400/zheng.jpg" /> 

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://lh6.ggpht.com/_ppBg9KfFNCQ/SifORadhvUI/AAAAAAAAA1M/Xz-gdixeKwQ/s400/fan.jpg" /> 

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://lh5.ggpht.com/_ppBg9KfFNCQ/SifOPjZ_T_I/AAAAAAAAA1I/WE7nG1yHeD4/s400/li.jpg" />