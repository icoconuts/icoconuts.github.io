---
title: 灭火器也可以这么鲜艳
author: elion
date: 2009-06-11T04:42:22+00:00
url: /2009/06/11/colorful-fire-extinguisher/
views:
  - 462
categories:
  - 分享好玩
tags:
  - 灭火器
  - 好文分享
  - hosted-on-i815.cn
draft: false

---
本文转自：[设计｜生活｜发现新鲜][1]

灭火器，在国内似乎只在各种场所出现。但在国外，很多现代家庭都会配备一支灭火器，

在公共场所，灭火器为了体现它的特殊性，必须采用统一的外观和色彩;而在家庭，这一点就显得不那么必要了。

法国 <a href="http://www.fire-design.fr/epages/270867.sf" target="_blank">fire design</a> 公司设计的有着鲜艳色彩和丰富图案的个性灭火器，能让灭火器成为一件富有艺术气息的装饰品，让更多的家庭愿意把灭火器带回家。

跳转后见图。

<!--more-->

<img loading="lazy" class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2008/10/fd37208c97b2_15097/firedesign01.jpg" alt="" width="468" height="500" /> 

<img loading="lazy" class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2008/10/fd37208c97b2_15097/securite_incendie_maison.jpg" alt="" width="468" height="312" /> 

<img loading="lazy" class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2008/10/fd37208c97b2_15097/extincteur_deco_cuisine.jpg" alt="" width="468" height="312" />

 [1]: http://since1984.cn/blog/y2009/fire-design.html