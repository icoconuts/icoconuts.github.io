---
title: Twitter相关指令的新手教程
author: elion
date: 2009-06-12T05:03:04+00:00
url: /2009/06/12/twitter-begginer/
views:
  - 368
categories:
  - 分享好玩
tags:
  - twitter
  - 暂无分类
  - hosted-on-i815.cn
draft: false

---
自从用上Twitter，感觉越来越喜欢它了。

之前<a href="http://127.0.0.1/2009/03/29/twitter-intro/" target="_blank">介绍过twitter</a>,今天从ifanr上转一个关于twitter相关指令功能的教程。

**1.Twitter的基本功能，就是4个**

自述（tweet，简称T），也叫更新状态（update），类似IM上的签名，向网络广播你的所思所想，所做所在。 <span style="color: #ff0000;">(是最基本的功能之一！)</span>

在官方web页面上显示就是：

> 办公室里收单位的无线信号，非常差。时断时连的，唉。。。
> 
> [about 4 hours ago][1] from [Gravity][2]

此Gravity就是此条tweet的发出端。

转述（Retweet，简称RT），你可以理解为自己把别人的话重新tweet一下，所以叫Retweet。

<!--more-->

在官方web页面上显示就是：

> RT @[inputx][3]: 现任苏州市委书记王荣，已被任命为深圳市委副书记，并将出任深圳副市长、代市长。有关任命将于日内宣佈。据悉王荣11日已到深圳，准备履新。
> 
> [about 4 hours ago][4] from [Gravity][2]

此条中，原消息是inputx发布的，觉得这条信息想分享给我的followers，让他们也看到这条tweet.意思就是相当于转推。

回应（Reply，简称RE，也用@标示），和你回复邮件和IM一样，就是回应。

在官方web页面上显示就是：

> @[miffi1987][5] 600M,多少钱?我30M都用不完。
> 
> [about 3 hours ago][6] from [Gravity][2] [in reply to miffi1987][7]

此条中，[miffi1987][5]是被回复对象，后面的是我回复的内容。

Direct Message（简称DM或者D），密信，直接（Direct）发送给某人的消息（Message），类似论坛PM。

在官方web页面上显示就是：

> **[wangzhonghao][8]**兄弟，你也是嘉兴人吗？
> 
> about 4 hours ago

此条中，wangzhonghao是信息发送者，DM的信息只有发送的双方看得到，followers是看不到的。

**2.为什么要这样命名？**  
为什么不使用write，foward，这些说法？tweet就很难理解？**因为它是twitter**，如果它是gwitter，可能就是regweet，对吧？这样理解了，我想别的就容易理解了。

**3.T,RT,RE,DM四个功能的区别：**  
a.除了DM，别的都是公开的。除了你，别人（follow你的人）也可以看到。  
最近Twitter更改了这个设置规则，变为：  
除了DM和你的部分回复，别的都是公开的。除了你，别人（follow你的人）也可以看到你。这里的部分回复是指你回复你自己的朋友时（自己的朋友意味着不一定是阅读者的朋友）  
b.DM，RT是一对一两人间的。T，RT都是一对多广播形式。

**4.什么是Follow和朋友**  
Follow，其实就是关注，你Follow了某人，就是你在关注他，所以，从他发出的公开消息（包括给你们共同朋友的回复），你都可以看到。比如，我们关注Jobs，那他所有的公开活动，我们都会了解到。同理，你不喜欢再关注他，就是Unfollow他了。  
如果你Follow的人也Follow你，说明他也在关注你，那你们当然就是朋友。如果Jobs也Follow ifanr，那我们之间就可以DM了，因为朋友间才有私语。这就是为什么有些人可以DM，有些不能的原因。

**5.twitter如何标记个人ID？tweet中的@和#分别是什么意思？**  
如果你的ID是ifanr，那么我们在twitter中用@ifanr 来表示你的ID。同时，@符号还有回复的意思，如果你在你的新tweet中直接在前面输入“@ifanr 内容”，那么你就是回复ifanr的意思。  
#则是tag，我把他当成是特定专有词汇，方便搜索和区别的。举例如下：  
Apple是一个通用名词，有苹果的含义也有苹果电脑的含义。如果你说：

> I Love apple，我们觉得你是喜欢吃苹果。  
> I Love #apple，我们知道你是喜欢苹果电脑。

最后，电脑客户端，我推荐,<a href="http://127.0.0.1/2009/05/09/air-twitter/" target="_blank">Destroytwitter</a>.

更多请看原文：<a href="http://www.ifanr.com/2337" target="_blank">Twitter和Gravity的101——简明有趣的教程</a>

 [1]: http://twitter.com/elion815/status/2124384616
 [2]: http://mobileways.de/gravity
 [3]: http://twitter.com/inputx
 [4]: http://twitter.com/elion815/status/2124652799
 [5]: http://twitter.com/miffi1987
 [6]: http://twitter.com/elion815/status/2125123409
 [7]: http://twitter.com/miffi1987/status/2125084141
 [8]: http://twitter.com/wangzhonghao