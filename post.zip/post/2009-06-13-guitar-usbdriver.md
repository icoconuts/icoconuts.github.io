---
title: 吉他造型镶宝石U盘挂饰
author: elion
date: 2009-06-13T04:40:36+00:00
url: /2009/06/13/guitar-usbdriver/
views:
  - 275
categories:
  - 分享好玩
tags:
  - 好物分享
  - hosted-on-i815.cn
draft: false

---
吉它造型，外加镶嵌宝石的U盘见过没有？

估计戴上这个，可以增加不少眼球！

<!--more-->

![][1] 

<p style="text-align: center;">
  非常耀眼吧？
</p>

![][2] 

[原文链接][3]

 [1]: http://www.blogcdn.com/chinese.engadget.com/media/2009/06/memo003100_04_l_resize.jpg
 [2]: http://www.blogcdn.com/chinese.engadget.com/media/2009/06/memo003100_02_l_resize.jpg
 [3]: http://cn.engadget.com/2009/06/12/jewel-guitar-usb-flash-drive/