---
title: WP分页插件:Paginator让分页导航更直观
author: elion
date: 2009-06-16T13:35:32+00:00
url: /2009/06/16/wp-paginator/
views:
  - 458
categories:
  - 折腾二三事
tags:
  - Paginator
  - WordPress
  - hosted-on-i815.cn
draft: false
---
博客日志越写越多，产生的页面也慢慢多起来了。之前一直用的页面导航是:<a style="color: #0066cc; text-decoration: none;" href="http://lesterchan.net/portfolio/programming/php/#wp-pagenavi" target="_blank">Pagenavi</a>。

<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://i3.6.cn/cvbnm/29/bf/07/54dbc0d8dad99e50f9cf4c29f8bbc5b9.jpg" alt="" width="547" height="150" />
</p>

它虽然比上一页和下一页好了很多，可以直接显示首尾页以及当前页面邻近的几个页面，但却无法直接跳转到想要查看的指定页面。

有了上面这个对比，下面介绍：<a style="color: #0066cc; text-decoration: none;" href="http://wordpress.org/extend/plugins/paginator/" target="_blank">Paginator</a>。

<!--more-->

<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://i3.6.cn/cvbnm/ee/fc/6a/8f2e9adaf9534b4845345ef258820ef5.jpg" alt="" width="460" height="118" />
</p>

通过插件选项设置，可以设置显示的页面数（至少2页）。上图我设置了20页。

<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://i3.6.cn/cvbnm/d4/95/15/3c697535512111af301830eb2ad7f1da.jpg" alt="" width="472" height="110" />
</p>

通过鼠标拖动可以自由选择指定的页面，非常直观，又方便！

简单说一下插件安装：

1.下载<a style="color: #0066cc; text-decoration: none;" href="http://wordpress.org/extend/plugins/paginator/" target="_blank">Paginator</a>，解压后，全部上传至博客目录下的“wp-content/plugins”文件夹。  
2.进入后台，激活Paginator插件。  
3.复制以下代码：

> <?php if(function\_exists(&#8216;wp\_paginator&#8217;)) { wp_paginator(); } ?>

放入index.php或其它有需要分页的php文件里，（简便方法就是搜你之前用的分页代码,如Pagenavi，替换就可以了。）

注：具体还要结合主题实际，其实最方便的就放在foot.php里。  
4 . 进入后台，设置显示的分页数就可以了。  
5 .要更改CSS样式，可编辑/ wp-content/plugins/paginator/skin/paginator3000.css

用鼠标手拖拽的也可以通过修改/ wp-content/plugins/paginator/skin/slider_knob.gif。

最后说一句，我想看过这个插件的朋友，肯定会毫不犹豫的它吧，因为真是没理由拒绝它！！！