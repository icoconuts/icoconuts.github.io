---
title: 用盘子来表达…
author: elion
date: 2009-07-22T04:18:28+00:00
url: /2009/07/22/style-dish/
views:
  - 297
categories:
  - 分享好玩
tags:
  - 创意分享
  - hosted-on-i815.cn
draft: false
---
看看有头脑的人就是不一样，原本就是一个常见的透明的盘子。  
加上一点点创意&#8211;底部加上凹下去的单词或短语。  
借助笔，你可以把想要选择的那个短语周围涂抹成红色，一句话就显现出来。<!--more-->

<img loading="lazy" class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2009/01/Imatalkingplate_A5C/plate01.jpg" alt="" width="468" height="303" />  
  
<img loading="lazy" class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2009/01/Imatalkingplate_A5C/plate09.jpg" alt="" width="468" height="117" /> 

<img class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2009/01/Imatalkingplate_A5C/plate02.jpg" alt="" />  
  
<img class="alignnone" src="http://since1984.cn/blog/wp-content/uploads/2009/01/Imatalkingplate_A5C/plate08.jpg" alt="" />