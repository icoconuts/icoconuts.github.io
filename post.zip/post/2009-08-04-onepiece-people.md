---
title: 转:OnePiece角色人物原型汇总(不断更新)
author: elion
date: 2009-08-04T11:52:04+00:00
url: /2009/08/04/onepiece-people/
views:
  - 377
categories:
  - 分享好玩
tags:
  - OnePiece
  - 杂文分享
  - hosted-on-i815.cn
draft: false
---
在百度贴吧看到这么一帖子，觉得真是要拜拜OP作者WT，他实在是太强大了。  

旦凡能创作出伟大动漫作品的人，其文化修养，精神世界绝对是非常丰富的。  

所以，联系到天朝，唉。。。又要说些沮丧的话了，在天朝这样的教育体制下，能培养出这样的人才出来么？  

不会！！！同样，大师，XX奖得主，也是与天朝无缘的。不是悲观，这是事实吧。 

不说了，还是看看OnePiece角色人物原型吧。真的是涵盖了太多面了。  

本文转自:[one piece角色人物原型汇总][1]  

部分原创~~  
  
USOPP(匹诺曹)

爱撒谎的孩子鼻子会变成，匹诺曹的经典形象和台词深深烙印在每个人的心中，和同样爱说大话的骗人布“大船长”相比。实在是很合适的特征呢，尤其是那个鼻子。  
<img loading="lazy" src="http://farm3.static.flickr.com/2674/3787762791_1bf6c326f8_o.jpg" alt="cf972909d08e37396a60fbf0" width="600" height="323" /> 

FRANKY(金凯瑞)  
大大咧咧的性格，精神百倍的飞机头，夏威夷沙滩衬衫，变态的表情和语言。无不就是一个金凯瑞。  
<img loading="lazy" src="http://farm4.static.flickr.com/3580/3788571622_160fdbfc39_o.jpg" alt="9c0310d6ac925f3206088bf0" width="601" height="330" /> 

**<span style="color: #ff0000;">(新)</span>**BROOK生前(Saul Hudson)  
著名的乐队‘枪炮与玫瑰’第一代的主音吉他手，也是该乐队的灵魂人物。Saul Hudson。  
于1996年退役。但是他的经典形象和对乐坛的影响一直延续至今。  
最近几年大卖的跨平台音乐节拍游戏《吉他英雄》封面依旧有他的频频登场。  
同是伦巴音乐海贼团的提琴手布鲁克，相同的爆炸发，相同的圆形墨镜，同样为音乐沉醉。  
算是WT对这位乐坛教父的致敬吧。  
<img loading="lazy" src="http://farm3.static.flickr.com/2463/3788685918_cb0be623d9.jpg" alt="46_122739_262a02f0461bb34" width="500" height="300" /> 

银狐福克斯(??)  
儿时曾看过的一部外国动画片，一个爱吃巧克力薄饼的巫师，但是遗憾的是该作品和人名已全然忘记。头发和鼻子尤其是福克斯生动的写照。  
<img loading="lazy" src="http://farm4.static.flickr.com/3421/3788571420_1d29572c0d_o.jpg" alt="ac0737ecad179020279791f0" width="601" height="329" /> 

海军三大将之一青稚(松田优作)  
青稚的原型当然是大名鼎鼎的松田优作了。英年早逝的天才演员，其中在异步电影里曾戴上眼罩出演。完全是活生生的青稚。  
<img loading="lazy" src="http://farm3.static.flickr.com/2644/3787763227_f25d2a0d0f_o.jpg" alt="8f9904136b930b9d6438dbf0" width="601" height="327" /> 

海军三大将之一黄猿(田中邦卫)  
黄猿的原型更神似。WT本人也曾坦言对田中邦卫老前辈很是敬重和喜爱。海军两大将都是日本知名的演员。  
<img loading="lazy" src="http://farm4.static.flickr.com/3419/3787763381_798cc7688f.jpg" alt="2846a1d31ad4771d3bf3cff0" width="500" height="273" /> 

海军三大将之一黄猿(北野武)  
这是一张流传比较广的，据说是WT泄露出来的赤犬图。不管真假与否，我倒是认为赤犬也一定是日本某知名的老前辈演员。现在民间呼声最高的无非是高仓健。而从这张有意思的图来看。我觉得是北野武老师比较有可能，年轻时曾因车祸而造成面瘫的他和该脸十分之相似。（虽然赤犬年轻时和这张完全不像.）  
<img loading="lazy" src="http://farm4.static.flickr.com/3546/3787764637_2c24b5be32.jpg" alt="00e5c2fb2d848e0b6c22eb42" width="500" height="424" /> 

雷能力者艾尼路(eminema)  
雷神艾尼路的原型在欧洲被普遍认为是乐坛说唱天王eminema。喜欢在两个大耳垂上弄耳环，以及那艾氏眼神。露额寸头。很传神。  
<img loading="lazy" src="http://farm3.static.flickr.com/2550/3787763501_e564ebdf95.jpg" alt="74dc9e23caa59753935807f3" width="500" height="273" /> 

**<span style="color: #ff0000;">(新)</span>**空岛原来的神 刚 霍尔(堂吉诃德)  
《堂.吉诃德》是西班牙的塞万提斯作于1605-1615年的长篇小说。世界文学名著。  
故事讲述穷乡绅堂吉诃德读骑士小说入了迷，决定仿效骑士的生活。  
于是穿上盔甲，骑着一匹瘦马，带着侍从出门行侠。结果闹了许多笑话，吃了无数苦头，直到临终才清醒过来。  
堂吉诃德的形象一直被很多名画家绘画成油画，插画，连环画。大都是有着可爱精神的老骑士形象。  
空岛的天空骑士很完美地体现了这个经典形象。WT的人物创作灵感向世界名著取经也不是什么新鲜事了。  
<img loading="lazy" src="http://farm3.static.flickr.com/2473/3788689158_4c04669080.jpg" alt="46_122739_d6c1d2796278117" width="500" height="300" /> 

海军科学部队队长战桃丸(金太郎)  
战桃丸是最无可争议的日本民间传说人物&#8212;金太郎。这个家喻户晓的神奇娃娃其经典的肚兜+西瓜头形象被用作很多卡通形象。  
<img loading="lazy" src="http://farm3.static.flickr.com/2530/3787763785_3742ab9dec.jpg" alt="56eb6124d693cd2e8644f9fe" width="500" height="272" /> 

催眠师赞高(迈克尔.杰克逊)  
催眠师赞高一出场就被人惊呼“快看，迈克尔.杰克逊！”这个流行教父其独特的舞步和动作，以及墨镜+帽子的组合，实在是太深入民心了。  
<img loading="lazy" src="http://farm4.static.flickr.com/3494/3788571808_9340af1b8b.jpg" alt="da9907ef763066f2cf1b3ef8" width="500" height="274" /> 

黑胡子海贼团音越(枪手)  
音越这个人物的形象很接近欧洲60年代中叶的枪手设定。有一本著名的第一人称少年文学经典《敏豪森男爵历险记》（也叫《吹牛大王历险记》）。该书在欧洲是每个孩子的必读课外书。之后被拍成电影。该书里，有一个形象设计很成功的枪手。就是现在音越的参照原型。  
<img loading="lazy" src="http://farm4.static.flickr.com/3031/3787764275_0cb353bedb_o.jpg" alt="50aad84a8f55873e08f7effc" width="595" height="323" /> 

新世界新星 霍金斯(slipnot)  
11超新星里的霍金斯和著名鬼脸摇滚乐队slipnot（活结）里的鼓手几乎是一个模子印出来的，特别是变成秸杆人后。  
<img loading="lazy" src="http://farm3.static.flickr.com/2650/3788572920_de4e18e88f.jpg" alt="0c255cef9fe48a2badafd5f0" width="500" height="272" />  
他们乐队的全家福&#8230;  
<img loading="lazy" src="http://farm3.static.flickr.com/2394/3787762181_0c01401171_o.jpg" alt="9c0310d658ab533206088b1f" width="501" height="367" /> 

新世界新星 罗(rokera)  
超高人气的罗的人物设计非常之成功啊，第一眼就喜欢上了。右边的人物也是普遍认为是他的原型。可是不知道这个大大到底是哪个人物- -|||。貌似名叫rokera。  
<img loading="lazy" src="http://farm3.static.flickr.com/2538/3787763963_ce2db6528a.jpg" alt="22b87e242968681c4d088dfc" width="500" height="271" /> 

**<span style="color: #ff0000;">(新)</span>**新世界新星 基拉(Daft Punk)  
“Daft Punk”是一支来自法国的乐队，他们以演奏电子乐为主。  
他们是两个经常扮成外星人亮相的家伙。Guy Man和Thomas Bangalter。  
其中成员Guy Man经常戴的那只外星人头盔与WT笔下的11超新星杀戮武人基拉超级吻合。  
Daft Punk也是世界电子乐界极具代表性的标志。  
<img loading="lazy" src="http://farm4.static.flickr.com/3531/3787880609_c8379b3630.jpg" alt="46_122739_0059dc10f9d8e9d" width="500" height="300" /> 

**<span style="color: #ff0000;">(新)</span>**新世界新星 波尼(辣妹曾根)  
日本大胃王比赛中经常看到一个娇小的身影，她就是「辣妹曾根」，23岁，45公斤，典型日本女孩，但是很会吃，  
据说一天能吃10几公斤。天生体质就很特别，光吃就是不长肉，羡煞一堆美眉。  
家里的冰箱是饭店厨房用的那种，是在太恐怖了。。。  
在日本享誉民间的大胃女王一定给了WT不少灵感来创作出11超新星里的大胃女波尼吧。  
<img loading="lazy" src="http://farm4.static.flickr.com/3475/3787880981_9cc25982cf_o.jpg" alt="46_122739_f7f29063db283d0" width="571" height="350" /> 

王下七武海 女帝 波雅 汉库克(苍井空？？-_-&#8216;or蛇女美杜莎?)  
女帝的原型有说是AV女优苍井空。理由是和作者同样是日本的。有说是某知名美女的。脸形激似。但是有一点可以确定的是，石化能力的设定以及”蛇姬“身份的确立，是以古老的蛇女美杜莎的骇人听闻的恐怖能力为原型而设计的。  
<img loading="lazy" src="http://farm4.static.flickr.com/3483/3787764377_8135f3e6df_o.jpg" alt="0b59b82e54c9574d4ec226fc" width="559" height="379" /> 

王下七武海 鹰眼 乔拉可尔 密佛格(zolo)  
鹰眼的装束和沉着冷静的个性。很符合民间的大英雄&#8212;剑客佐罗。无论是穿着还是气质，甚至神秘的出现都是一样让人兴奋的出场。  
<img loading="lazy" src="http://farm3.static.flickr.com/2521/3787762661_feebbbc6d3_o.jpg" alt="2846a1d31ac8771d3bf3cffc" width="600" height="323" /> 

巨人战士 青鬼东利和红鬼布罗基(云长和益德)  
两位巨人的形象第一眼就让人觉得很亲切。一个长脸长胡子，一个宽脸大胡子，都是嗜酒的豪爽之人。其实这个设定的人物随处可见，但是中国的读者更愿意相信这是从关二哥和张三哥的形象里获得的启发。要知道，关二哥可是在国外都有很高很高的知名度的。  
<img loading="lazy" src="http://farm3.static.flickr.com/2530/3788572622_704239db62.jpg" alt="049a241bcfa039048718bffc" width="500" height="194" /> 

推进城副看守长多米诺(女军阀)  
推进城的女军官（尤其是副看守长多米诺）的设定都是参照了美国早些时候的性感女军阀的装束设计。儿时看过美国电影的人一定都记得那些金发小帽，大胸呼之欲出的身材极好的女军阀们或者是军阀秘书。  
<img loading="lazy" src="http://farm4.static.flickr.com/3433/3787762509_996cd3ed33_o.jpg" alt="ec882da1e2a3be964610643c" width="344" height="279" /> 

蛇(蛇)  
玛格丽特身边的小蛇和迪士尼作品的《森林王子》里的那条小蛇有区别没？  
<img loading="lazy" src="http://farm4.static.flickr.com/3503/3787869699_fca7504b06_o.jpg" alt="5f586003327e61f109fa93fc" width="600" height="328" /> 

**<span style="color: #ff0000;">(新)</span>**神秘的CP9(Bauta)  
在说神秘人之前，说说水之都,看到水之都的第一印象，我想很多人都想起威尼斯吧？  
对，WT肯定是拿威尼斯当成了水之都的原型。  
那么，在水之都里，大家可以看到大量的面具，就能解释了。  
威尼斯的面具文化在欧洲文明中独具一格，是极少数面具溶入日常生活的城市。  
18世纪以前，威尼斯居民生活完全离不开面具，人们外出，不论男女，都要戴上面具，披上斗篷。  
这专属于威尼斯的面具就是那有名的“包塔”（Bauta）。  
威尼斯人把面具作为日常生活的一部分有着悠久的历史。  
依旧是那水之都，依旧是那些小艇也依旧出现了戴着面具披着斗篷的“未知人”。  
尽管阴谋重重的氛围，但是WT依然把水之城浪漫华羡的气韵带给了神秘的CP9。  
<img loading="lazy" src="http://farm4.static.flickr.com/3494/3787880425_704ec76fd1.jpg" alt="46_122739_1868592cd46a320" width="500" height="300" /> 

**<span style="color: #ff0000;">(新)</span>**世界政府五老星之一(戈尔巴乔夫)  
末代苏共中央总书记 ,第一位兼最后一位苏联总统。  
他对于苏联的影响和意义十分深远，在国际上也享有很高的声誉和名望。  
头上标志性的红色胎记，就像世界地图板块，和五老星里的“地图头”是在是太相似了  
胖圆脸，位高权重，地图胎记。。。不难相信尾田多少从这个大人物上至少借鉴了些许特征。  
<img loading="lazy" src="http://farm3.static.flickr.com/2557/3787881043_69941dec1c_o.jpg" alt="46_122739_65a14a5e1defefa" width="512" height="226" /> 

知识扩展一下:  
OnePiece里世界政府最高权力就是五老星。基于上面的之一是以前苏联总统为原形，那我么想其它四位，一定是其它有影响力的人物吧。拿剑的那个的原形，自然是Japanese吧。。。这里涉及的政治因素就不多讨论了。  
有兴趣的，或知识渊博的，可以帮忙找一下。  
<img loading="lazy" src="http://farm4.static.flickr.com/3525/3788773076_310d94b006_o.jpg" width="598" height="130" alt="wlx" /> 

**<span style="color: #ff0000;">(新)</span>**幽灵岛 豪格巴克(企鹅人)  
《蝙蝠侠归来》里的反面角色秃头企鹅人。这个造型的成功一直被人津津乐道。  
豪格巴克与其有着很多相似的特征，同样的滑稽身材，同样的小眼尖鼻，  
同样的在故作高雅的绅士气质的背后进行着自己的野心勾当。  
个性，造型鲜明的各种电影，小说，连环画里的反面角色，都是漫画家取材的源泉。  
<img loading="lazy" src="http://farm4.static.flickr.com/3574/3788689862_082a005ef2.jpg" alt="46_122739_9a141dd73a75b6e" width="500" height="300" /> 

**<span style="color: #ff0000;">(新)</span>**人妖王 伊万(洛基恐怖秀 主角)  
人妖王伊凡科夫刚登场，其大脸红唇，眼影卷发，紧身黑衣，高筒网袜的男扮女装形象就立刻让人联想到电影《洛基恐怖秀》。  
这部带有未来主义色彩的奇特惊悚片在当时引起了剧烈的反响，人们更多的是记住了主角饰演的两性人形象。  
同是人妖，又同样的化妆盒服装，看来WT大神也是相当喜欢这部美国邪典电影啊。并把他用在了自己的人物上。  
<img loading="lazy" src="http://farm3.static.flickr.com/2668/3788689926_a62f22c622_o.jpg" alt="46_122739_b514e4080d4ea3e" width="450" height="409" />  
不断更新&#8230;

 [1]: http://tieba.baidu.com/f?kz=533014797