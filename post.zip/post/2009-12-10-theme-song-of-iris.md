---
title: 换了个手机铃声
author: elion
date: 2009-12-10T11:54:45+00:00
url: /2009/12/10/theme-song-of-iris/
views:
  - 98
categories:
  - 生活记事
tags:
  - 日记
  - hosted-on-i815.cn
draft: false
---
买了三三后的第一件事就是换了个铃声，

那时候正在看蓝色生死恋。

哇，那音乐超棒~~  

马上做成手机铃声了，一用就是好几个月。  

人家都说现在什么年代了，还用纯铃声，但是我确实喜欢。

就一直没换。  

最近，看着IRIS，确实挺好看的。  

那主题曲，白智英的“不要忘记”，每每在男女主角相互思念的时候想起。很是感人啊。  

于是，新的手机铃声就出来了~~~~  

分享给大家啊~~  
  
附：  
[蓝色生死恋铃声][1]  
[短信息铃声][2]  
[IRIS-主题曲：不要忘记-白智英][3]

 [1]: http://www.box.net/shared/phay1nvivf
 [2]: http://www.box.net/shared/xoh2q9ba54
 [3]: http://www.box.net/shared/jfegi0bxg3