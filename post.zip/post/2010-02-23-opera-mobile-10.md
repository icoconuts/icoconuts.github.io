---
title: Opera Mobile 10 for S60试用
author: elion
date: 2010-02-23T12:33:16+00:00
url: /2010/02/23/opera-mobile-10/
categories:
  - 分享好玩
tags:
  - E63
  - hosted-on-i815.cn
draft: false
---
三三上装的浏览器已经很多啦，像UC，Go，Skyfire，还有Opera Mini。

今天看到CB上关于<a href="http://www.cnbeta.com/articles/104750.htm" target="_blank">Opera Mobile 10 for S60 发布</a>的介绍，马上下了个试试~~

于是，写个试用感受，分享给大家。

**1.关于Opera**

Opera，一直是个传说。

Opera，她既大名鼎鼎，又是个小众软件。她的用户忠诚度非常高，而且用户群非常稳定。

Opera，她是浏览器技术的领军者，但把这些技术发扬光大，为世人所知的并非是她。

Opera，她一直是“千年老二”。在这么多年，大大小小的浏览器技术测评中，她一直存在着，但她一直是那些抢文的陪衬。

**2.关于Opera Mini**

在早些年，手机浏览器市场竞争没这么激烈，Opera Mini绝对是当时的佼佼者。我一直用到了4.2国际版。

**3.关于Opera Mobile**

Opera专门为智能手机设计的产品，以前用Nokia 6220的时候，只能用用Opera Mini。

现在用上三三了，终于可以享受Opera Mobile带来的全新体验了。

更多关于Opera Mobile的介绍，就点<a href="http://www.opera.com/mobile/" target="_blank">官网</a>吧。

<!--more-->

**4.下载及安装**

用手机直接下载的，输入：<a href="http:m.opera.com/mobile" target="_blank">http:m.opera.com/mobile</a>,然后选择for s60 亚洲版。

用电脑下载的，输入：<http://www.opera.com/mobile/download/>,选择国际版。

安装就不多说了，不会安装程序的，去google下。

好了，不多说了，开始试用上图了。

对了，还多说一句，用Opera Mobile的，建议选用WiFi连接，不然流量吓死你…

1.主界面

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm3.static.flickr.com/2522/4381997366_d8e78ab33f_o.jpg" alt="" /> 

Opera Moblie设计了新的时尚操作界面，我的第一感觉非常棒。比起FireFox移动版的界面好太多啦~~

同样，Opera Moblie加入了**Speed Dial**功能，当然现在各浏览器已经非常流行了。称呼也不一样。

2.网页浏览

输入[hjx.me][1]，试试主页显示效果。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4070/4381997394_2b1c8e3302_o.jpg" alt="" /> 

这里我选用的是Fullscreen Mode：off状态。

去除了CSS定义的效果。网页打开非常流畅，浏览效果很不错。

3.操作

按键盘左键，弹出工具栏及输入框。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4062/4381997596_244d8b5d42_o.jpg" alt="" /> 

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4050/4381239653_28cc3ca819_o.jpg" alt="" /> 

从左至右，分别是：Startpage(首页)，back(后退)，Forwar(前进)，Reload/Stop(重载/停止),Exit(退出)。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4031/4381239681_6f10bae2eb_o.jpg" alt="" /> 

导航键往下移，将是：Bookmarks(收藏夹)，History(历史)，Saved Pages(保存网页) ，Downloads(下载) Settings(设置)， Find in Page(查找) ，Help(帮助)。这里着重介绍Settings。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm3.static.flickr.com/2748/4381239475_ca3a3df95f_o.jpg" alt="" /> 

Load images：ON/OFF

[Opera Turbo][2]：ON/OFF

[Opera Link][3]：ON/OFF

Mobile view：ON/OFF

Fullsreen mode：ON/OFF

Zoom：60%-200%

Privasy

Advanced

关于Fullsreen mode，刚才说过了。个人感觉，如果用Wifi浏览的话，选上吧。

另外，Opera Turbo选上的话，图片质量会下降许多。

4.多页面浏览

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4021/4381239723_3711b2e444_o.jpg" alt="" /> 

试试Cnbeta吧。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm3.static.flickr.com/2734/4381239519_9fce311b6d_o.jpg" alt="" /> 

Cnbeta的页面。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://farm5.static.flickr.com/4057/4381239743_ea6b354aa1_o.jpg" alt="" /> 

这是点滴快乐的页面。

在电脑端习惯了使用的标签式浏览，这下，在手机端同样也可以在多个页面间方便地来回切换。

简单地就介绍这些吧。

有兴趣地试试吧。用户体验绝对是很棒的。

<p id="oplink">
  #什么是Opera Link
</p>

Opera最新推出的浏览器同步功能。使用 Opera Link，您可以随时随地访问您的浏览器信息。Opera Link 使您可以随心所以在任何地方访问书签和其它有用信息，无论您是在工作，在家，还是在路上使用手机。您可以在多台计算机上同步您的书签，甚至可以同步它们到手机上的 Opera Mini/Opera Mobile浏览器，或者登录 Opera Link 网络版（当您碰巧用其它浏览器时依然可以访问您的 Opera 书签）。

Opera Link 可以同步您的浏览器，这样您的浏览器数据可以随处调出。Opera Link 使您可以在任意地方访问您的书签和其它有用信息，无论您在工作、在家还是在路上使用手机。

Opera Link 同步您的：书签/快速拨号/个人栏/笔记/浏览器输入历史/定制搜索。

<p id="turbo">
  #什么是Opera Turbo？
</p>

Opera Turbo是存在于Opera 10和Opera Mobile中独创的压缩技术。Opera Turbo在窄带环境下网页浏览速度比同类浏览器快8倍，为身处慢速网络环境中的你提供激动人心的浏览速度。如果你必须付费浏览网页的话，它会通过减少数据量来为你省钱。

若想启动Opera Turbo，你只需点击Opera 10浏览器左下角的Opera Turbo图标即可。之后你尽可安稳享受快速的网上生活了。

了解更多关于

<a href="http://www.opera.com/browser/turbo/" target="_blank">Opera Turbo</a>的信息。

 [1]: http://127.0.0.1
 [2]: #turbo
 [3]: #oplink