---
title: 三款Chrome上的Twitter客户端扩展
author: elion
date: 2010-03-23T15:25:31+00:00
url: /2010/03/23/3-twitter-clients-4-chrome/
categories:
  - 分享好玩
tags:
  - Chrome
  - twitter
  - hosted-on-i815.cn
draft: false
---
在不能用DestroyTwitter后，PC上上Twitter总感觉不太爽~~

虽然有网页版，但总觉得没有独立的客户端来得舒服。

FireFox不是很喜欢，也说不出什么理由。不然Tweetfox绝对是个不错的选择。

至于Chrome，开始支持插件后，一直在寻找关于Twitter扩展。

一共试用了以下三款。

1.[Metrist][1]

2.[Chromed Bird][2]

3.[Chrowety][3]

Metrist和Chromed Bird就不多做介绍了。

个人推荐使用[Chrowety][3]！

<!--more-->

用起来最舒服了，今天就着重介绍一下这款Chrome浏览器twitter扩展！

1.下载并安装[Chrowety][3]扩展。

&#160;

2.安装后，就会在你的chrome浏览器地址栏后面多了一个图标，可以通过拖动调整位置！

（图中左起第2个。）

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/7a/a5/0e/cac13997f8684c833e9a9599e184798d.jpg" /> 

&#160;

&#160;

3.设置。

通过右击，选择设置。

这些都很基本，就不多说了。

主要讲2个。

第一，提供了desktop alerts功能，默认是关闭的。如果你不嫌烦，那就开着吧。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/bb/df/6d/ee756875732ad91d4d896efbf09bcfa0.jpg" /> 

提示就显示在电脑右下角：

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/3a/81/ba/6a717cf052806697fab68cb16a74789a.jpg" /> 

第二，如果你在墙内，那你基本要选择通过API了，还没有自己的API proxy,自己<a href="http://127.0.0.1/2009/07/10/twitter-api-proxy-gae/" target="_blank">建一个</a>吧。

&#160;<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/a2/97/a0/a29dbff69891bf3e68aa2b5eb6c76652.jpg" />

&#160;

4.使用

点击即可出现整个界面了。

一条上分别是：主页，回复，私信，收藏，列表。

并且你可以看见home那里有个数字一，表示这里有一条未读tweet，当然这个数字提示在mentions和message都有！

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/9b/87/b3/d09c8c221c9d46036d70998f233ed187.jpg" /> 

&#160;

回复的效果也挺特别，只需要鼠标点击别人tweet下面的那条线就可以自动弹出一个对话框：

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/c9/ed/22/d93b8a7f2f752635bf73e24ac4cd6854.jpg" /> 

&#160;

还有一点就是Retweet的时候，还要再点一下edit，才能加上你的话。这个我觉得最好还可以增加个设置。

最后，还有个特别的，点击第一行右侧的倒数第二个图标,她就会以popup的形式展现了。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/06/bc/92/98f80e6783c5558fd74d08bd70ff6fe9.jpg" /> 

&#160;

5.建议

使用下来，感觉很不错。但是还有些时候还要用到网页版。

比如，要follow某个人，它的链接还是要跳到官网，作为墙内用户的话，这可就郁闷了…

还有希望最新版本能增加自定义字体的设置。还是习惯用雅黑~~

 [1]: https://chrome.google.com/extensions/detail/aefaeloiencfjnaljicdoieoekoecmha?hl=en-us
 [2]: https://chrome.google.com/extensions/detail/encaiiljifbdbjlphpgpiimidegddhic?hl=en-us
 [3]: https://chrome.google.com/extensions/detail/ffcbeckjmgmgigkmnhmgjplmomcpfall?hl=en-us