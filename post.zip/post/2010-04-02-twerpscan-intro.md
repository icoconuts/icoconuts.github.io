---
title: Twitter批量Follow/Unfollow-TwerpScan
author: elion
date: 2010-04-02T12:59:52+00:00
url: /2010/04/02/twerpscan-intro/
categories:
  - 折腾二三事
tags:
  - twitter
  - hosted-on-hjx.me
draft: false

---
<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://i44.tinypic.com/30ufrlu.jpg" alt="" />

Twitter用久了后，following和follower的人数自然而然就会慢慢上去了。

这是个积累的过程。

但是，人渐渐多起来，有时候谁fo了你，而你有没有fo他，自己也理不清了。

还有就是fo了一段时间下来，觉得有些推自己完全不去关注，那这类人建议也去unfo了吧。

一来屏幕上清静，二来手机流量也可以省点~.~

<!--more-->

## TwerpScan

使用[Twerpscan][1]就可以轻松进行批量操作了。

1.通过twitter验证（需翻墙…）

2.选择你要进行的操作对象。比如：所有你following的人。

<img loading="lazy" style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://i43.tinypic.com/ffcpqc.jpg" alt="" width="572" height="242" /> 

这里清楚的列出了你following的人的信息。

最左侧的五星代表你同时也fo了他，是间的绿色标签代表他fo了你。

再右边分别代表此人的foers/followings/rates/tweets/.

那么通过此页面，你可以单个的unfo或是block。

当然，你应该批量操作。

其它的就不多说了。

大刀阔斧的干吧…

 [1]: http://www.twerpscan.com/en "http://www.twerpscan.com/en/"