---
title: iPod Touch 3 代入手一周有感
author: elion
type: post
date: 2010-04-15T14:18:17+00:00
url: /2010/04/15/itouch-7days/
categories:
  - 分享好玩
tags:
  - iPod
  - 好物分享
  - hosted-on-hjx.me
draft: false
---
之前<a href="http://127.0.0.1/2010/04/09/my-itouch/" target="_blank">图文并茂</a>，介绍了iTouch的购买动机和现场拆封实图。

话说入手iPod Touch 3代已快一周了，这几天一有时间都没闲着，几乎一直在研究着这宝贝呢。

今天就详细介绍入手一周后的感受。

我想任何一位入手iTouch/iPhone的朋友，真心的研究过机子，充分的发挥它的作用的话，你真的会由衷的发出这样的感慨！

It’s Amazing!!!

真是太强大了！简直不可思议那！绝对的NB！！

刚入手的时候，许多人都问我，这玩意要2000？除了听歌、视频，还能干嘛？

我不回答，我只要一个人乐着就行了，呵呵~~

<!--more-->

<p class="biaot">
  一、关于机子
</p>

1.外观

地球人都知道iPhone了，也不多说描述了。

> “3.5英寸1620万色的多点触控屏幕，分辨率为480×320像素，显示精细度为163ppi。”

相比iPhone：

1.没有听筒。这样更简洁了。

2.厚度，iTouch的厚度仅有8mm，基本上是iPhone的60%。

3.没有摄像头。

4.背部镜面上，明显写着iPod。o(∩_∩)o&#8230;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://img.product.pchome.net/market/photo/2009/08/24/372881b.jpg" /> &#160;

2.电池

和所有的iPod一样，iPod Touch的电池隐藏在金属外壳下不可随意更换。

但也不用太担心，按照每天充2次电计算，电池至少也能用二三年吧。

所以，不要太担心，尽情享用吧。

&#160;

3.保护

iTouch/iPhone绝对是需要保护的。因为他的前面和后面都太脆弱了。

记得在购机前，在论坛上看帖子的时候，就看到好多“前辈”们发出感慨：“后盖一定要贴膜或加套！”

所以，在机子到手后一直就用一个布袋(买无线鼠标的时候送的，大小正好。)装着iTouch。

不过，即使这样，用了几天后，后盖就出现几条刮痕了。

实在等不及弟弟五一的时候回家帮我带保护的套子了。

在淘宝看了两天后，发现全身膜实在太少。

于是选择了Air Jacket，超薄的后盖。

正宗的想想没必要，三五十元的就行了。

颜色还是和三三相呼应吧&#8211;透明红色。

另买了一块膜，二十五。

上图。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i39.tinypic.com/8zl6d3.jpg" /> 

<p align="center">
  iTouch VS E63
</p>

<p align="center">
  <img src="http://i41.tinypic.com/2mmaf03.jpg" />
</p>

<p align="center">
  还是挺薄
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i39.tinypic.com/2qixrx5.jpg" /> 

<p align="center">
  个人挺喜欢这红色的套子
</p>

<p align="center">
  &#160;
</p>

<p class="biaot">
  二、关于播放
</p>

iTouch的第一定位是Mp4播放器。

这点不可否认，但说实话，我想买iTouch的人中90%应该不是冲这个去的吧？

至少俺不是冲这个去的。

1.音乐

俺平时不怎么听歌，对音质这东西也实在不是懂。

不过，提醒一句对音质有极高要求的朋友，你真要买来听音乐，那您还是买classic吧。

另外，32G的容量，要放多少歌，你看着办吧。

2.视频

iTouch/iPhone这么流行，也不担心这样片源的吧。

不过，试用了好几款大家推荐的视频转换软件，效果不太理想。觉得转一部电影花的时间实在太慢。

好在，我这方面要求也不高。平时放些MV和动画片就行了。

另外，还可以通过优酷和酷6等在线观看视频。

3.图片

iTouch/iPhone通过多点触摸，可以用两个手指同时划动来放大、缩小图片，单指拨动可以察看局部或翻页换图。</p> </p> 

320*480的图片尺寸。

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://www.365iphone.cn/Image/20090716095018579.jpg" /> 

秀一下壁纸。

&#160;

<p class="biaot">
  三、关于软件
</p>

有点长了，请翻下一页。 <!--nextpage-->

软件

之前说了，买iTouch的人中90%不是冲音质去的，而是冲着背后App store中数以万计的软件去的。

如今苹果独特的在线商店模式，已经取得了巨大的成功，各大厂商纷纷推出自己的XXX store。

用户可以通过PC端和iTouch/iPhone访问App store，方便下载所需要的软件或游戏。

目前就整了这么些软件，我们的目标是：每天多一点。哈哈~

<p align="center">
  第一页：
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i40.tinypic.com/1177ekn.jpg" /> 

系统自带的都在这第一页了。

1.Mail.很好很强大。很有用。

2.Contacts.既然不是手机，这个MS用不上，但是写邮件的时候，用得着吧。

估计通讯录保留下来的意思应该是吸引喜欢PDA功能的用户吧。

3.Photo.图片浏览。

4.Maps.基本用不上。

5.Youtube.在中国就是个杯具。在twitter上听说在SB会举办期间，上海将可以访问Youtube?

6.Calendar.还没用过。得找个软件，能同步G Calendar的。

7.Weather.可以。偶尔用用。

8.Note.熟悉虚拟键盘挺不错的。当日记写写~~不过今天下了GTD管理类软件。这个估计要被冷漠了。

9.Clock….

10.Calculator….

11.Voice Memos.暂时还没用到。

12.Stocks.o,绝缘。

13.Videos.影片浏览。

14.iTunes.很好。

15.App store.把它放在最容易点到的地方。哈哈~~

&#160;

<p align="center">
  第二页：
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i42.tinypic.com/i56ava.jpg" /> 

&#160;

<p align="center">
  第三页：
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i44.tinypic.com/2llj12b.jpg" /> 

&#160;

<p align="center">
  第四页：
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i44.tinypic.com/v7zjo9.jpg" /> 不逐一说了，以后有机会慢慢介绍吧。

&#160;

<p class="biaot">
  四、关于使用
</p>

<p class="biaot">
  1.iTouch的触感就不用多说了。
</p>

<p class="biaot">
  始祖就是始祖，我试用过5800、M8、iTouch 2 Gen、iPhone 3GS，感觉还是iTouch 3的反应速度是最快的。
</p>

<p class="biaot">
  这绝对不是吹的。
</p>

<p class="biaot">
  2.买iTouch，一定要装iTunes。
</p>

没有iTunes，你的iTouch会挺无奈的。

iTunes和iTouch是最好的伙伴了。关于iTunes，以后也一定专门再介绍了。

3.忘记说了，最重要的一点，一定得有Wifi信号，不然，iTouch也仅仅就是个大号的播放器了。

WIFI的热点现在应该是越来越多了，这个应该可以放心。

至少现在对于我来说，家里有，工作地方有，就已经OK了。

&#160;

总的来说，iTouch就是有史以来最好玩的iPod了。

如果你对音质的要求不是特别高，喜欢它的外表，喜欢各类的软件，那选iTouch吧，你一定爱上她。