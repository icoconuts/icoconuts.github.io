---
title: Google比百毒更喜欢我的博客
author: elion
date: 2010-04-26T14:17:27+00:00
url: /2010/04/26/goolgebetterthanbaidu/
categories:
  - 折腾二三事
tags:
  - 建站相关
  - hosted-on-hjx.me
draft: false

---
在GR上看到CB新闻一则：<a href="http://www.cnbeta.com/articles/109553.htm" target="_blank">报告称一季度百度市场份额上涨谷歌下滑</a> 

于是，马上打开链接，想去看看百毒被骂成什么样了。

自然，CB上都是关注IT的人士聚集的地方，百毒被骂骂也是正常。

文中写道：

> 百度一季度的市场份额由58.4%拉升至目前的64%，而谷歌的市场份额从上一季度的35.6%下滑至本季度的31%。

但就我个人而言，一个月使用百度的次数快接近于零了。

有时候百度给出的搜索结果，也可以说是搜索结果排序很让人无语。

<!--more-->

越来越少用百度的原因，更多的是因为百度更好着执行着ZF各种各样的搜索过滤，一如继往的自我阉割着。

自网站从搬家至hjx.me后，我的网站统计从4月1日数据清零后重新开始统计。

有趣的现象就是：

&#160;

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/04/ba/8f/250219063b5c2f595ae374b6c13cb40c.jpg" /> 

<p align="center">
  网站概况
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/8a/74/32/cd9ca8cab741c052d9f6014a89e98849.jpg" /> 

<p align="center">
  4.1-4.25搜索引擎比例
</p>

<img style="display: block; float: none; margin-left: auto; margin-right: auto" src="http://i3.6.cn/cvbnm/2e/83/74/359add0f7581645df24bbe37f4c4b3dd.jpg" /> 

<p align="center">
  近七日的搜索引擎比例
</p>

<p align="left">
  e…我只能说Google比百毒更喜欢我的博客？
</p>