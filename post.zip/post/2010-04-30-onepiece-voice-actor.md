---
title: 海贼王声优配音现场
author: elion
type: post
date: 2010-04-30T14:30:49+00:00
url: /2010/04/30/onepiece-voice-actor/
categories:
  - 分享好玩
tags:
  - OnePiece
  - 视频分享
  - hosted-on-hjx.me
draft: false
---
<embed src="http://player.youku.com/player.php/sid/XNzU3NDgxNDg=/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>

感觉挺有意思的。

具体配音的应该是那个剧场版：

“乔巴传记- 绽放在寒冬的奇迹樱花”