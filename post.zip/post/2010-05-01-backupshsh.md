---
title: 备份iPod Touch/iphone3.1.3SHSH
author: elion
date: 2010-05-01T11:33:12+00:00
url: /2010/05/01/backupshsh/
categories:
  - 折腾二三事
tags:
  - ipod
  - SHSH
  - hosted-on-hjx.me
draft: false

---
<p style="text-align: center;">
  <img loading="lazy" class="aligncenter" src="http://i44.tinypic.com/xefj2h.jpg" alt="" width="594" height="150" />
</p>

自从购入iPod Touch以来，一直就有关于3.1.3要出越狱软件的消息。  
但结果就是一直被忽悠。  
这次&#8230;这次应该是真的了。  
Comex近期在他的[twitter][1]上留言说周五（也就是我们这的五一）放出越狱软件Spirit，但因故推迟。原因就是苹果在同一时间发布了3g版的iPad。  
但神奇的是，3g版的iPad也于今天顺利越狱，也就是说，事情没有变化，comex的Spirit越狱可以用在iPad 3G上。

总之一句话，3.1.3完美越狱的日子真的马上就要到了。

&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;-

但是在越狱前以下事情是一定要做的：

> 无论是iPhone 3GS、iPod touch 3或者iPad的用户，如果你打算越狱3.1.3的话，请务必做好备份3.1.3的SHSH的工作。因为Spirit发布之后，苹果将会很有可能在最快的时间内将越狱所利用的漏洞给封杀。封杀后那些未能备份3.1.3的SHSH的用户将无法继续利用Spirit进行越狱。

备份SHSH前，先了解下SHSH:

> 什么是iPhone 3GS和iPod Touch 3G的ECID （Exclusive Chip ID）？  
> 就是iPhone3GS的身份证号，每一个iPhone3GS （或者iPod Touch 3g）都有自己的独特的ECID。

> 什么是SHSH和它有什么用处？  
> 如果通过验证服务器就送一个和ECID对应的文件SHSH到iTunes，这样iTunes就可以继续进行固件的恢复。iPhone3Gs和iPodTouch 3g出来时候，苹果为加强对iPhoneOS的控制对恢复（Restore）固件（Firmware）采用了验证过程，每次iTunes要恢复固件的时候都要连接苹果的服务器验证(ECID就送到了服务器）。严格的说，不是“备份”SHSH，是去苹果的服务器上读取SHSH保存。SHSH，只存在于苹果的服务器上。

> 另，现在到苹果的服务器只能取到3.1.3的了，即使你的iPhone（iTouch）固件版本是3.0，3.1，3.12，你现在也只能取到3.1.3的。

原先备份SHSH要先提取ECID，然后再通过umbrella备份。现在用到下面的软件，就完全不用担心，只需要几分钟就行了。（本人已备份好。）

AUTOSHSH3.1.3（<a href="http://www.uushare.com/user/elion/file/2949258" target="_blank">点我下载</a>）

安装此程序前需要如下环境：<a href="http://javadl.sun.com/webapps/download/AutoDL?BundleId=39494" target="_blank">JAVA</a>和<a href="http://www.microsoft.com/downloads/details.aspx?FamilyID=333325fd-ae52-4e35-b531-508d977d32a6&DisplayLang=zh-cn" target="_blank">.NET Framework 2.0或以上</a>。

<img loading="lazy" class="alignnone" src="http://resource.weiphone.com/resource/h003/h00/img201005011349590.jpg" alt="" width="500" height="334" /> 

<p class="biaot">
  使用方法：
</p>

1.给你的iPod Touch/iPhone 3GS/iPad关机。（不是锁屏，是持续按住关机键，等提示关机在移动滑块的关机）。

2.关机后，按住home件（不知道的面壁去&#8230;）<span style="color: #ff0000;">不放</span>，插上USB，没过几秒便会出现“USB线连接itunes图标”。

3.打开你下载来的AutoSHSH软件，一路确定，ok！

记得事先安装java。

最后在你电脑上会得到一个64K的文件就是了。

备份SHSH工作完毕。

最后就祈祷Spirit快点放出吧！！！

 [1]: http://twitter.com/comex