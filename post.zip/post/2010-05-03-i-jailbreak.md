---
title: Spirit发布-实现完美越狱
author: elion
date: 2010-05-03T15:23:45+00:00
url: /2010/05/03/i-jailbreak/
categories:
  - 折腾二三事
tags:
  - iPod
  - 经验整理
  - 越狱
  - hosted-on-hjx.me
draft: false
---
<img loading="lazy" class="aligncenter" title="spirit" src="http://i44.tinypic.com/2jcu6j7.jpg" alt="spirit" width="594" height="150" />

这次果然是真的了。

在前几天3G版iPad越狱成功后，今天早上，我6点多更新twitter的时候，就发现iH8sn0w在其twitter上重复警告大家：

> This is another reminder that ALL iPhone 3GS/iPod Touch 3rd Gen/iPad users MUST grab their SHSH blobs for 3.1.3/3.2!

具体操作方法，可以参看此日志：<a href="http://127.0.0.1/2010/05/01/backupshsh/" target="_blank">备份iPod Touch/iphone3.1.3SHSH</a>。

今天上午，有事在外面，但一直有预感会发布Spirit，于是不停的盯着威锋的itouch区。

激动的时刻终于到来，10点不到，就看到坛友们在讨论破解的事了。之后就是源源不断的帖子涌现了。

<!--more-->

实在是正好有事在外面，真恨不得马上回家，下载Spirit，完成越狱啊。

下午回到家，做了些准备就开始越狱了。

<p class="biaot">
  一、准备工作：
</p>

1.下载<a href="http://www.uushare.com/user/elion/file/2964254" target="_blank">Spirit</a>。

a.将解压后的Spirit.exe存放于**纯英文路径**的目录下。（类似D:\ipt\JB\spirit.exe)

b.同步下应用软件，备份下有用的信息。（比如：anote的日记，ixpenseit的帐务信息还有照片等等。）

虽然实践证明，这些是多余的，但还是小心为秒。

c.越狱软件可能被某些杀毒软件视为病毒，暂时先关闭杀毒软件及防火墙。

2.iTunes的话，在没放出Spirit前，就听大神们说要用9.0.3版本的。于是，我就犯了个大错误。在卸载原版本的时候，把IPA文件统统删掉了。导致后面有点小杯具，但就是浪费点时间而已。

实践证明，任何版本的iTunes 9 (包括9.1.1)环境下，都可以正常完成越狱。

3.另外的前提：

a.如果你目前使用的是不完美越狱，需要恢复使用Spirit。如果你对iPhone 3G/3GS使用了解锁，不要升级。（但如果你备份有3.1.2的SHSH blob，你可以恢复到3.1.2。）

b.设备需激活：屏幕停留在Connect to iTunes或Emergency Call界面的设备，不能越狱。

<p class="biaot">
  二、越狱步骤：
</p>

这里只说说我自己的越狱过程。

Win XP用户连接好iPhone/iPod touch/iPad(别太紧张，也别多问，就很普通的用数据线插上电脑就行了)，直接运行Spirit.exe。即可进行越狱，傻瓜的不能再傻瓜了。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://img1.gtimg.com/digi/pics/hv1/152/229/509/33156272.jpg" alt="" /> 

顺便弄了张图

完成越狱后，重启后看到Cydia，那就说明成功了。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://resource.weiphone.com/resource/h003/h00/img201005031147390.jpg" alt="" /> 

之后，需要做的事太多了，有空再说吧。