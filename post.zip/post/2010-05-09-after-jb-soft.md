---
title: iPod touch/iPhone越狱后的软件推荐
author: elion
date: 2010-05-09T09:23:44+00:00
url: /2010/05/09/after-jb-soft/
categories:
  - 分享好玩
tags:
  - iPod
  - hosted-on-hjx.me
draft: false
---
<img loading="lazy" alt="" src="http://i44.tinypic.com/258q7g3.jpg" class="alignnone" width="480" height="100" />

朋友，在i系列全设备越狱的时代，你的iphone/iPod Touch/iPad越狱了没？

之前的日志里，由于本人的机子是3.1.3版本的，所以一直没有提及越狱。

但是没有让我等很久，在5月3日上午**Dev Team**发布了Spirit。<a href="http://127.0.0.1/2010/05/03/i-jailbreak/" target="_blank">越狱教程点这里</a>。

<!--more-->

当然，在没越狱的这一个月左右的时间里，我也大概了解iPod Touch上iPhone OS，以及现在被各大厂商纷纷模仿的APP Store模式。

这种模式下，用户可以通过免费或付费的方式，非常方便的下载到你所喜欢的各类程序或游戏。而且，你会用着用着你会发现，免费的程序有各种各样的限制。如Awesome note，一款非常棒的todo+note类的软件，它的免费版却只能储存10篇note。

在越狱无望的那个时候，真有冲动去花美刀买些程序。

当然，除了以上需求，还有另一些方面，比如，未越狱前，系统给予用户的权限是极低等等。

牢骚就不多说了，毕竟已经苦尽甘来。

在iphone/iPod Touch/iPad实现越狱后，许多用户也包括俺有太多的茫然，也需要太多的折腾。

所以，就想写下这篇，记录下我的这些折腾。

首先，先参考了许多的日志：

[可能吧 &#8211; 10个优秀的免费iPhone软件推荐][1]

<a href="http://dayanjia.com/2010/02/10-apps-you-should-install-after-jailbreak-your-ipod-touch-or-iphone.html" target="_blank">iPod To uch / iPhone 越狱后必装的 10 款软件</a>

<a href="http://bbs.weiphone.com/read-htm-tid-772203.html" target="_blank">威锋论坛 &#8211; 『WEIP技术组』全设备越狱时代到来，Spirit越狱工具发布！</a>

<p class="biaot">
  一、配置你的Cydia
</p>

关于Cydia的教程有许许多多，我也没有任何的创新。有需要了解的，Google一下吧。

> Cydia作用是打开文件系统，让我们可以直接修改系统内的文件。越狱步骤，其实做到安装Cydia就已经完成了。

> 它能让你添加各种软件源，获取只有越狱后才能使用的各种软件和界面主题。Cydia由神人[Saurik][2]开发，目前早已替代了早先越狱机器中的软件管理软件Installer。尽管目前有Icy这样更为轻巧的软件包管理程序，但是无疑Cydia更加成熟，提供了更加接近系统底层的操作。如今，各种需要付费才能使用的软件也渐渐在Cydia的软件商店中出现。

在Spirit越狱完成后，就默认安装好了Cydia。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://i44.tinypic.com/vzctoz.jpg" alt="" /> 

目前我的机子上就以下几个Cydia源：

Hackulo: <a href="http://cydia.hackulo.us/" target="_blank">http://cydia.hackulo.us/</a>

威锋网：<http://app.weiphone.com/cydia>

电玩巴士：<http://iphone.tgbus.com/cydia/>

iCosta: <a href="http://iphone.freecoder.org/apt" target="_blank">iphone.freecoder.org/apt</a>

更多的Cydia源，可以参看此贴：[bbs.weiphone.com/read-htm-tid-306430.html][3]

<p class="biaot">
  二、安装相关补丁
</p>

AppSync for  OS3.1：IPA软件的安装补丁，打上这个补丁后，你才可在itunes里安装破解程序。

请选择Hackulo这个源里的AppSync for  OS3.1补丁。

AFC2补丁：本人从没用过91助手，也一直不会用91助手。所以就不去安装这个补丁了。

<p class="biaot">
  三、安装越狱后的必备程序
</p></p> 

1.保护Home键：mQuickdo (原名：iHome)

version:1.4.4

> 在越狱前，按Home键的频率非常之高。
> 
> 如果不加节制，非常担心Home键很快就会失灵。
> 
> 使用了近一星期的mQuickdo之后，按Home键的次数几乎可以将为0了。不是装13。
> 
> 真的是因为用了mQuickdo之后，关闭或切换程序非常的方便。
> 
> 就像你习惯了鼠标手势后，就不会再去点图标一个道理。

安装方法：可通过“电玩巴士”提供的mquickdo，安装后即可。

1.4.4破解版下载:[uushare下载][4]

使用方法：mquickdo提供的方案实在太多，我几乎只设置了3种。

上面：

（1）向右短滑/长滑：关闭程序对话框

（2）向左短滑/长滑：关闭系统对话框

（3）按住2秒/3秒：截图

下面：

（4）向左短滑/长滑：回到home

（5）向右短滑/长滑：锁住机子

（6）按住2秒/3秒：截图

（7）按住向上滑：切换程序

<img loading="lazy" style="display: inline; margin-left: 0px; margin-right: 0px;" src="http://i39.tinypic.com/ot42v7.jpg" alt="" width="274" height="411" align="left" /> 

<img loading="lazy" src="http://i41.tinypic.com/55m0js.jpg" alt="" width="273" height="410" /> 

2. iFile

verson:1.2.0-1

此程序也是越狱必备程序。它一个文件管理器，使用它你可以在iPod Touch/iPhone上轻松地操作文件系统。

该程序的内置许多文件查看器，支持播放多媒体文件、编辑文本文件、查看PDF和Microsoft Office文件，还可以压缩/解压文件，还可以方便的通过Wi-Fi和电脑互传文件。

iFile是一款非常强大的文件浏览/管理工具。

现在，iFile在Cydia上已经是收费软件了。

安装方法：在Cydia中搜索“iFile”即可找到它并安装（付费软件以蓝色字显示），未注册版本的功能有一些限制，但是没有使用时间限制。

1.2.0-1破解版:<a href="www.uushare.com/user/elion/file/2984430" target="_blank">uushare下载</a>

使用方法：就是一文件管理器。可以方便的移动/复制/编辑/新建/查看文件。

ifile还可以修改文件夹权限，还可以安装deb文件。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://i41.tinypic.com/be92qo.jpg" alt="" /> 

3. Backgrounder

iPod Touch/iPhone不支持多任务（4.0马上就可以了。）

Backgrounder就可以实现多任务运行。

安装方法:直接在源里搜索安装即可。

使用方法：设置后台运行的方式。

这里我选择了双击状态栏，这样非常方便。

以后，双击状态栏，就会出现“Backgrounding Enabled”。

如果要退出后台运行，只要重复一遍，就会出现“Backgrounding Disabled”。

4.Installous

version:3.1

有了它，就可以在iPod Touch/iPhone上安装.ipa文件（App Store的软件格式）了。

iTunes虽然可以手动管理音乐和视频，但是不能手动管理应用程序的，所以如果你在两台不同的电脑上就不能同步应用程序了（一旦同步会把原来的应用程序全部删掉）。

所以能在终端上安装ipa文件的程序就是最好的选择。

ipa文件来源有二：

1.程序自带有下载功能。

2.可将ipa文件传到/var/mobile/Documents/Installous/Downloads目录下进入程序安装。

<img style="display: block; float: none; margin-left: auto; margin-right: auto;" src="http://i39.tinypic.com/1puu7s.jpg" alt="" /> 

安装方法：在hackulo 源找到installous，安装即可。

使用方法：略。

5.输入法

目前，iPod Touch / iPhone中已经自带了简体中文和繁体中文以及手写输入法，但还是没有我想要的“五笔输入法”！

在未越狱的时候，只能凑合着用着拼音。

越狱后，可不能再委屈自己了。

两款主流的五笔输入法：

1.[iCosta][5]

2.[WeFit][6]

这里就不多做评测了，大家看自己喜欢了。

安装方法：在icosta源和威锋的源里分别能找到，安装即可。

 [1]: http://www.kenengba.com/post/769.html
 [2]: http://www.saurik.com/
 [3]: http://bbs.weiphone.com/read-htm-tid-306430.html
 [4]: http://www.uushare.com/user/elion/file/2984435
 [5]: http://iphone.freecoder.org/
 [6]: http://wefit.weiphone.com/