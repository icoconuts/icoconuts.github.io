---
title: 网站搬迁结束
author: elion
date: 2011-01-18T14:30:49+00:00
url: /2011/01/18/todasfree/
categories:
  - 折腾二三事
tags:
  - WordPress
  - 建站相关
  - hosted-on-hjx.me
draft: false
---
网站搬迁结束咯~~

速度还是可以的吧？？

召唤各位Reader!!!

PS:今天开始下雪，今年的冬天特别冷啊！！