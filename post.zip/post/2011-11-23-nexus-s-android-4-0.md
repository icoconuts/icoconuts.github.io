---
title: Nexus S成功运行Android 4.0
author: elion
date: 2011-11-23T07:42:22+00:00
url: /2011/11/23/nexus-s-android-4-0/
categories:
  - 分享好玩
tags:
  - 视频分享
  - hosted-on-hjx.me
draft: false
---
<embed src="http://player.youku.com/player.php/sid/XMzE4OTM0MTk2/v.swf" allowFullScreen="true" quality="high" width="480" height="400" class="ptsp" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash">
</embed>

期待啊&#8230;