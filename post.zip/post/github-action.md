---
title: "通过Github Actions实现Hugo自动部署"
date: 2021-03-12T13:59:15+08:00
tags: ["hugo"]
slug: "2021-03-12-2"
draft: false
---
参考了几个帖子：

> [Github Actions自动生成Hugo站点并部署到Github Pages](https://unixetc.com/post/auto-build-hugo-site-and-deploy-to-github-pages/) 


终于实现了！
