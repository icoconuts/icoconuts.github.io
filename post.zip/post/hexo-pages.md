---
title: "为Hexo添加常用页面"
date: 2016-05-13T17:29:15+08:00
tags: ["hexo"]
slug: "hexo-pages"
draft: false
---

发表于HEXO

在网站架设完成后，除了发布文章以外，还应该通过新增功能页面，来完善网站的功能。

现在许多优秀的Hexo的主题都预设了许多功能页面，如about,tags,categories,404,RSS等等页面。

当然你可以通过设置仅仅保留首页。

# 生成页面

进入你的Hexo文件夹，命令行输入：（需要哪些生成哪些，名字可以自定义）



```
hexo new page "about" #关于页面
hexo new page "tags" #标签页面
hexo new page "categories" #分类页面
hexo new page "404" #404页面
```

# 编辑页面

在\Hexo\source\下找到你需要编辑的页面文件夹下的index.md.

- About页面：可直接编辑自己需要添加的内容。

- Tags页面只需要如下修改就可以了：

  ------

  title: Tags
  date: 2016-X-X XX:XX:XX
  type: “tags”
  comments: false #如需要关闭评论，则添加comments: false

  ------

- Categories页面只需要如下修改就可以了：

  ------

  title: Tags
  date: 2016-X-X XX:XX:XX
  type: “categories”
  comments: false #同上

  ------

- 404页面稍微复杂一些：

首先要在404页面最上面添加如下代码：

```
---
title: 404 该页无法显示 #可自定义名称
toc: false #目录功能关闭
comments: false #评论关闭
permalink: /404 #永久链接为404.html
---
```

之后可以添加些自定义的话，以及一个首页链接等。自己发挥。

由于Github本身提供404页面，如果要用自定义的404页面的话，前提是你已经绑定的顶级域名才可。

# 通过主题配置文件配置

找到你的主题文件夹下的主题配置文件,修改保存即可。

```
menu:
  home: /
  archives: /archives 
  tags: /tags
  categories： /categories
  about: /about
```

[#Hexo](http://hjxme.github.io/tags/Hexo/)