---
title: "将本地Hexo部署到Github"
date: 2016-05-11T16:29:15+08:00
tags: ["hexo"]
slug: "hexo-theme"
draft: false
---

发表于HEXO

其实，看了很多教程，他们都喜欢把这个步骤放到很前面讲，可能比较迎合许多人的想法。

但我觉得，真正想做好一个网站或者说是自己的小站，架设仅仅是开始。

更多的是将通用的模板，修改修改再修改成自己喜欢的，自己想要的才是最重要的。

等到以上完成后，我想这才是将网站放上去的时候了。

# 申请Github

这一步并不是必须的，你也可以放到七牛、coding.net等国内其名的云空间上。但Github,毕竟是太有名了。



至于以后Github会不会被墙，谁也不知道。

申请的步骤就不说多了，想架hexo的，这点都会。

# 部署到Github

一般的部署都是通过SSH，如果是第一次使用SSH部署的话，还需要以下几步，命令行输入：

```
git config --global user.email xxx@xx.com　＃你的邮箱名
git config --global user.name xxx
```

再生成SS文件，命令行输入：

```
ssh-keygen -t rsa -C xxx@163.com(邮箱地址)  #生成ssh
```

然后，再本地找到 id_rsa.pub 文件，打开后复制代码，到Github里设置添加SSH公钥即可。

可以通过命令行检验，，命令行输入：

```
ssh -T git@github.com
```

回车，回车。

得到以下结果，说明就可以了。

```
Hi username! You’ve successfully authenticated, but GitHub does not provide shell access.
```

修改hexo文件夹下的_config.yml配置文件

初学者最最需要记住的是：每个：后面需要有一个空格否则会发生错误。

在该文件的最后找到并修改成：

```
deploy: 
 type: git 
 repository: git@github.com:XXX/XXX.github.io.git #这里改成你的ID
 branch: master 
```

再部署之前，再输入命令行：

```
npm install hexo-deployer-git --save
```

最后，输入命令行：

```
hexo d
```

部署完毕。

以后，建议每次部署的步骤，可按以下三步来进行。

```
hexo clean
hexo g
hexo d
```

部署Hexo完成。

[#Hexo](http://hjxme.github.io/tags/Hexo/)Hexo主题配置

发表于 2016-05-11  |  分类于 [Hexo ](http://hjxme.github.io/categories/Hexo/) |  

# 挑选主题

找到你想要的主题，如果还没找的话，可以去官网看看。戳[这里](https://hexo.io/themes/)。

找到主题后，https://github.com/XXX/XXXX.git

## 安装主题

到主题目录下，命令行输入：

```
git clone https://github.com/XXX>/XXXX.git
cd XXX
npm install
```



## 启用主题

到hexo根目录下，修改站点配置文件“_config.yml”中theme属性值为，你的theme文件夹下，所要使用的文件夹的名称。

## 更新主题

找到需要更新的主题文件夹，右键菜单下的Git Bush here，命令行输入：

```
git pull
```

更新前请先备份主题目录下的_config.yml文件。

具体的主题修改，由于各个主题的不同，修改方案也不同。我就不再详细说了。

[#Hexo](http://hjxme.github.io/tags/Hexo/)