---
title: "初识Hexo与Hexo安装"
date: 2016-05-10T18:29:15+08:00
tags: ["hexo"]
slug: "hexo-1"
draft: false
---

发表于HEXO

# 认识Hexo

> Hexo，快速、简洁且高效的博客框架。官方网站戳[这里](https://hexo.io/zh-cn/)，支持中文。
>
> 特点：
>
> 1.超快速度
> Node.js 所带来的超快生成速度，让上百个页面在几秒内瞬间完成渲染。
>
> 2.支持 Markdown
> Hexo 支持 GitHub Flavored Markdown 的所有功能，甚至可以整合 Octopress 的大多数插件。
>
> 3.一键部署
> 只需一条指令即可部署到 GitHub Pages, Heroku 或其他网站。
>
> 4.丰富的插件
> Hexo 拥有强大的插件系统，安装插件可以让 Hexo 支持 Jade, CoffeeScript。

好吧，其实我感觉Hexo比WordPress复杂多了。之前折腾WP，只要找好空间，添加好数据库，再通过FTP上传本地配置好的文件，就可以了。

但折腾了几天Hexo后，感觉是陌生的一个框架。

为什么选择Hexo，一个字“轻”！

是的，这一点是我一直向往的，本身架设自己的博客不是为了啥，只是为了完成自己网上安家的梦而已。

不求多少的点击量，不只求安放一个小小的站点。

# 安装Hexo



## 环境需求

就像WP的环境需要，一个能够运行PHP语言的主机空间和一个MySQL数据库。

Hexo是基于Node.js的静态博客框架，同时也需要Git把本地的hexo内容提交到github上去。

1. Git 下载并安装
2. Node 下载并安装
3. 申请GitHub

以上全部完成后就可以正式安装Hexo，以后的事情感觉都在命令行里完成了。

## 安装Hexo

1.电脑上安装Hexo到全局，命令行输入：

```
npm install -g hexo
```

如果无法安装，可以试试墙内的npm，命令行输入：

```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```

2.在电脑上完成安装后，你需要在某个文件夹下创建你的网站文件夹了。比如在E:\hexo.

找到E:\hexo\,右键菜单下的Git Bush here.

我们需要初始化hexo文件夹，命令行输入：

```
hexo init
```

再需要安装依赖和插件，命令行输入：

```
npm install
```

如果使用了淘宝源，那么就是:

```
cnpm install
```

如果成功的话，在E:\hexo下就应该是这样的。

[![img](http://7xtxby.com1.z0.glb.clouddn.com/2016-05-11_151557.png)](http://7xtxby.com1.z0.glb.clouddn.com/2016-05-11_151557.png)

## Hexo 文件简介

_config.yml：网站的配置信息，重要！配置大部分的参数修改都在这。

package.json：应用程序的信息，已默认安装，可以自由移除。

scaffolds文件夹：在你新建文章时，Hexo会根据scaffold来建立文件。

source资源文件夹：是存放用户资源的地方。

themes主题文件夹：Hexo会根据主题来生成静态页面。

3.生成静态页面

初始化完成之后，系统自动生成一篇“hello word”的文章了，现在我们生成为静态页面，命令行输入：

```
hexo generate
```

以后习惯了就输入：

```
hexo g
```

4.本地启动

把文章变为页面之后，我们可以通过本地启动服务来预览，命令行输入：

```
hexo server
```

以后习惯了就输入：

```
hexo s
```

要查看生成的页面效果，就在浏览器中输入http://localhost:4000/

[![img](http://7xtxby.com1.z0.glb.clouddn.com/123123.jpg)](http://7xtxby.com1.z0.glb.clouddn.com/123123.jpg)

## 常用命令

Hexo的命令简单，安装后常用的就这几个。执行命令需要Git here当前处于自己的博客所在目录下。

```
hexo g #generate 生成静态文件。

hexo s #server 启动服务器。

hexo d #deploy 部署网站。部署网站前，需要预先生成静态文件。

hexo clean #clean 清除缓存文件 (db.json) 和已生成的静态文件 (public)。
```

至此，Hexo本地架设完成！