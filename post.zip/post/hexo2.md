---
title: "Hexo生成文章"
date: 2016-05-10T21:29:15+08:00
tags: ["hexo"]
slug: "hexo-2"
draft: false
---

发表于HEXO

# 初阶

生成文章

找到E:\hexo\,右键菜单下的Git Bush here.命令行输入：（依次输入）

```
hexo n post1
hexo g
hexo d
hexo s
```

编辑文章

在E:\hexo\source_posts中有post1.md文件

再到进入http://localhost:4000/，看看新发布的文章。

# 进阶



其实以上命令还有可选参数：

```
hexo new [layout] "postName" #新建文章
```

其中layout是可选参数，默认值为post。

在根目录下的scaffolds目录下，这些文件名称就是layout名称。默认有3个。

当然你可以添加自己的layout，方法就是添加一个文件即可，同时你也可以编辑现有的layout，比如post的layout默认是 hexo\scaffolds\post.md

```
---
title: {{ title }}
date: {{ date }}
tags:
---
```

请注意，大括号与大括号之间我多加了个空格，否则会被转义，不能正常显示。

我就不是很喜欢tags来对我的文章进行分类，那么，可以添加categories，只需要修改这个文件添加一行，如下：

```
---
title: {{ title }}
date: {{ date }}
categories： #文章分类目录，可以为空，注意:后面有个空格
tags: #文章标签，可空，多标签请用格式[tag1,tag2,tag3]，注意:后面有个空格
---
```

postName是md文件的名字，同时也出现在你文章的URL中，postName如果包含空格，必须用”将其包围，postName可以为中文。

注意，所有文件：后面都必须有个空格，不然会报错。

至于，对MD文件的编辑，有各式各样的方法，Mac端和Win端都有优秀的MD编辑软件，也有在线的MD编辑软件。

现在，手机端也是有的。

目前，我自己选择的是MarkdownPad。

[#Hexo](http://hjxme.github.io/tags/Hexo/)